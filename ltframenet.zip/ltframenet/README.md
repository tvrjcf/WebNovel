# ltframenet
LTFrame.net is .net framework export of ltframe,it's Can be used in .NET framework,current version it's run in windows 7、8、9、10 ,but it's  run in xp has some bug, I'm trying to solve



LTFrame using the .Net Framework written

LTFrame runs in the Windows2000 or higher operating system

You can use the VS2005, VS2008, vs2010,vs2012,or higher version of the VS for the application development,minnum .NET Framework use 2.0

The use of LTFrame is totally free and you can use it in any application.
