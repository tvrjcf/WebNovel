/*func*/
var _path = 'book',
    _userAgent = 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25';

function scroll_class(strid, offset) {
        var module = '',
            href = 'images/scroll/scroll/',
            list = new Object(),
            isw3c = document.compatMode == 'CSS1Compat',
            body = isw3c ? document.documentElement : document.body,
            tb_offset = 1;
        this.strid = strid;
        this.sH2_offset = offset == null ? 0 : offset;

        function $() {
                return document.getElementById(arguments[0])
            };

        function isfirefox() {
                return window.addEventListener != null
            };

        function getOffset(evt) {
                var target = evt.target;
                if (target.offsetLeft == undefined) target = target.parentNode;
                var pageCoord = getPageCoord(target);
                var eventCoord = {
                    x: window.pageXOffset + evt.clientX,
                    y: window.pageYOffset + evt.clientY
                };
                var offset = {
                    offsetX: eventCoord.x - pageCoord.x,
                    offsetY: eventCoord.y - pageCoord.y
                };
                return offset;
            };

        function getPageCoord(element) {
                var coord = {
                    x: 0,
                    y: 0
                };
                while (element) {
                    coord.x += element.offsetLeft;
                    coord.y += element.offsetTop;
                    element = element.offsetParent;
                }
                return coord;
            };

        function getEventOffset(evt) {
                var ox = new Object();
                if (evt.offsetX == undefined) {
                    var evtOffsets = getOffset(evt);
                    ox.offsetX = evtOffsets.offsetX;
                    ox.offsetY = evtOffsets.offsetY;
                } else {
                    ox.offsetX = evt.offsetX;
                    ox.offsetY = evt.offsetY;
                }
                return ox;
            };
        this.func = function (id, height, _div_h) {
                var obj;
                if (list[id] == null) {
                    list[id] = new Object();
                    try {
                        var _id = $(id);
                        list[id].isbody = _id.tagName == 'BODY';
                        list[id].main = list[id].isbody ? body : _id;
                        list[id].div = list[id].main.getElementsByTagName('div')[0]
                    } catch (e) {
                        return
                    };
                    obj = list[id];
                    if (_div_h != null) {
                        var _div = document.createElement('div');
                        _div.style.visibility = 'hidden';
                        _div.style.height = _div_h + 'px';
                        obj.div.appendChild(_div)
                    };
                    obj.scr_bar_top = 0;
                    var _p = obj.main.style.position;
                    if (_p != 'absolute') _p = 'relative';
                    obj.main.style.position = _p;
                    obj.main.style.overflow = 'hidden';
                    if (height == null) height = obj.main.offsetHeight;
                    obj.div.style.overflow = 'hidden';
                    var sH2 = this.sH2_offset;
                    this.sH2_offset,
                    sH3 = parseInt(obj.main.style.paddingTop);
                    if (!isNaN(sH3)) sH2 += sH3;
                    sH3 = parseInt(obj.main.style.paddingBottom);
                    if (!isNaN(sH3)) sH2 += sH3;
                    sH3 = parseInt(obj.main.style.marginTop);
                    if (!isNaN(sH3)) sH2 += sH3;
                    sH3 = parseInt(obj.main.style.marginBottom);
                    if (!isNaN(sH3)) sH2 += sH3;
                    obj.div.style.paddingBottom = sH2 + 'px';
                    var d = document.createElement('div');
                    d.id = 'scroll_track_' + id;
                    d.setAttribute('_type', 'scroll');
                    d.style.position = 'absolute';
                    d.style.top = '0px';
                    d.style.right = '0px';
                    d.style.background = 'url(' + href + 'scr_track.gif)';
                    d.style.height = height + 'px';
                    d.style.width = '8px';
                    d.style.overflow = 'hidden';
                    d.style.visibility = 'hidden';
                    d.onselectstart = function () {
                        return false
                    };
                    d.ondragstart = function () {
                        return false
                    };
                    d.innerHTML = '<div _t="track" onmousedown="' + this.strid + '.downtrack(\'' + id + '\')" id="scroll_track2_' + id + '" style="position:absolute;top:' + tb_offset + 'px;width:8px"><div id="scroll_bar_' + id + '" onmousedown="' + this.strid + '.mousedown(\'' + id + '\')" onmousemove="' + this.strid + '.mousemove()" onmouseup="' + this.strid + '.mouseup()" style="width:6px;position:absolute;left:1px;top:0px;background:url(' + href + 'scr_bar.gif);overflow:hidden"><img src="' + href + 'scr_bart.gif" style="position:absolute;top:0px"><img src="' + href + 'scr_barb.gif" style="position:absolute;bottom:0px"></div></div>';
                    obj.main.appendChild(d);
                    obj.scr_track = d;
                    obj.scr_track2 = $('scroll_track2_' + id);
                    obj.scr_bar = $('scroll_bar_' + id);
                    obj.scr_top = 0;
                    obj.div.scrollTop = obj.scr_top;
                    obj.main.onmousewheel = function () {
                        eval(strid + '.wheel(\'' + id + '\')')
                    };
                    obj.main.onkeydown = function () {
                        eval(strid + '.keydown(\'' + id + '\')')
                    }
                } else obj = list[id];
                if (height == null) height = obj.main.offsetHeight;
                var sH = obj.div.scrollHeight;
                if (obj.height == height && obj.sHeight == sH) return;
                obj.height = height;
                obj.sHeight = sH;
                obj.height2 = obj.height - tb_offset * 2 - (obj.isbody ? 4 : 0);
                obj.main.style.height = obj.div.style.height = height + 'px';
                if (obj.sHeight <= obj.height) {
                    obj.scr_track.style.visibility = 'hidden';
                    return
                };
                obj.scr_track.style.height = height + 'px';
                obj.scr_track2.style.height = obj.height2 + 'px';
                var bh = parseInt((obj.height / obj.sHeight) * (obj.height2));
                if (bh < 20) bh = 20;
                obj.scr_bar_height = bh;
                obj.scr_bar.style.height = bh + 'px';
                obj.scr_min = 0;
                obj.scr_max = obj.height2 - bh;
                obj.scr_step = (obj.sHeight - obj.height) / (obj.height2 - bh);
                obj.scr_track.style.visibility = 'visible';
                if (obj.load != null) this.goloc(id, obj.div.scrollTop);
                obj.load = 1
            };
        this.downup = function (id, v, s) {
                try {
                    if (id == null) id = this.id;
                    var obj = list[id],
                        r = 1;
                    var th = s != null ? v : (parseInt(obj.scr_bar.style.top) + v);
                    if (th < obj.scr_min) th = obj.scr_min,
                    r = 0;
                    if (th > obj.scr_max) th = obj.scr_max,
                    r = 0;
                    obj.scr_bar.style.top = th + 'px';
                    obj.scr_bar_top = th;
                    obj.div.scrollTop = obj.scr_step * th;
                    obj.scr_top = obj.div.scrollTop;
                    return r
                } catch (e) {}
            };
        this.goloc = function (id, v) {
                this.keydown(id, 0, v)
            };
        this.keydown = function (id, k, s) {
                if (k == null) k = event.keyCode;
                var obj = list[id],
                    h = obj.height;
                if (s != null) u = s;
                else switch (k) {
                    case 33:
                        u = obj.scr_top - h;
                        break;
                    case 34:
                        u = obj.scr_top + h;
                        break;
                    case 36:
                        u = 0;
                        break;
                    case 35:
                        u = 999999999;
                        break;
                    case 38:
                        u = obj.scr_top - h / 2;
                        break;
                    case 40:
                        u = obj.scr_top + h / 2;
                        break
                    };
                if (u == null) return;
                obj.div.scrollTop = u;
                u = obj.div.scrollTop;
                this.downup(id, u / obj.scr_step, 1)
            };
        this.wheel = function (id) {
                var delta = 0;
                if (event.wheelDelta) {
                    delta = event.wheelDelta / 120;
                    if (window.opera) delta = -delta
                } else if (event.detail) {
                    delta = -event.detail / 3
                };
                var h = list[id].scr_bar_height;
                if (delta) this.downup(id, delta > 0 ? -h : h)
            };
        this.downtrack = function (id) {
                var e = event.srcElement;
                if (e.getAttribute('_t') != 'track') return;
                var obj = list[id];
                var y = getEventOffset(window.event).offsetY;
                this.downup(id, y < obj.scr_bar_top ? -obj.scr_bar_height : obj.scr_bar_height)
            };
        this.mousedown = function (id) {
                this.id = id;
                this.y = event.clientY;
                this.y2 = this.y - list[id].scr_bar_top
            };
        this.mouseup = function () {
                this.id = null
            };
        this.mousemove = function () {
                if (this.id == null || event.button != 1) return;
                var y = event.clientY,
                    s = y - this.y;
                var y3 = this.y - list[this.id].scr_bar_top;
                if (this.downup(null, s) == 1) this.y = y;
                if (this.y2 != y3) this.downup(this.id, y - this.y2, 1)
            };
        this.resize = function () {
                for (var n in list) try {
                    this.func(n)
                } catch (e) {}
            };

        function init() {
                this.oldmousemove = document.onmousemove;
                this.oldmouseup = document.onmouseup;
                document.onmouseup = function () {
                    try {
                        this.oldmouseup()
                    } catch (e) {};
                    eval(strid + '.mouseup()')
                };
                document.onmousemove = function () {
                    try {
                        this.oldmousemove()
                    } catch (e) {};
                    eval(strid + '.mousemove()')
                };
                window.setInterval(function () {
                    eval(strid + '.resize()')
                }, 100)
            };
        init();
    };
var _scroll = new scroll_class('_scroll');
var config = new Object(),
    main = new Object();
main.pType = getSearch('ptype');
if (main.pType == '') main.pType = '0';
config.defaultkey = '请输入书名/作者名';
config.charset = '936';
config.his = _path + '\\his';
config.fav = _path + '\\fav';
config.isIE6 = navigator.userAgent.toLowerCase().indexOf('msie 6') > 0;
var redraw_w, redraw_h;

function redraw() {
        var w = document.body.clientWidth,
            h = document.body.clientHeight;
        if (w == redraw_w && h == redraw_h || h < 300) {
                window.setTimeout('redraw()', 100);
                return
            };
        redraw_w = w;
        redraw_h = h;
        try {
                resizehtml()
            } catch (e) {};
        window.setTimeout('redraw()', 100)
    };

function time_func(a) {
        var _a = a,
            t = parseInt(Date.parse(new Date()) / 1000);
        if (a == null) return t;
        a = t - a;
        var u = a;
        if (u == 0) return '刚刚';
        if (u < 120) return u + '秒前';
        u = parseInt(a / 60);
        if (u < 60) return u + '分钟前';
        u = parseInt(a / 3600);
        if (u < 60) return u + '小时前';
        var cdate = new Date(parseInt(_a) * 1000);
        var u = cdate.getFullYear() + '-' + (cdate.getMonth() + 1 > 9 ? cdate.getMonth() + 1 : '0' + (cdate.getMonth() + 1)) + '-' + (cdate.getDate() > 9 ? cdate.getDate() : '0' + cdate.getDate());
        return u
    };

function clip(v) {
        window.clipboardData.setData("Text", v)
    };

function api_GetPathList(path, stype) {
        try {
            return external.ts_getpathlist(path, stype)
        } catch (e) {
            return ''
        }
    };

function api_DesktopLnk(name, act, link) {
        if (act == null) act = 'get';
        if (link == null) link = '';
        try {
            return external.ts_desktoplnk(name, act, link)
        } catch (e) {
            return '0'
        }
    };

function api_DesktopTtx(name, act, info) {
        if (act == null) act = 'get';
        if (info == null) info = '';
        try {
            return external.ts_desktopttx(name, act, info)
        } catch (e) {
            return '0'
        }
    };

function api_OpenTab(id, url) {
        try {
            external.ts_opentab(id, url)
        } catch (e) {}
    };

function api_GetTabs() {
        try {
            external.ts_gettabs()
        } catch (e) {}
    };

function api_CloseTab(id) {
        try {
            external.ts_closetab(id)
        } catch (e) {}
    };

function api_OpenIe(u) {
        try {
            external.ts_openie(u)
        } catch (e) {}
    };

function api_FullScreen(u) {
        try {
            external.ts_fullscreen(u)
        } catch (e) {}
    };

function api_SelectStart() {
        var e = event.srcElement;
        if (e.tagName == 'INPUT' || e.tagName == 'TEXTAREA') return true;
        return false
    };

function api_KeyDown() {
	alert("api_KeyDown");
        var e = window.event,
            s = e.srcElement.tagName,
            k = e.keyCode;
        if ((k == 8 && s != 'INPUT' && s != 'TEXTAREA') || k == 116) {
                e.keyCode = 0;
                return true
            };
        return true
    };

function api_Init() {
        document.onkeydown = function () {
			return true;
            return api_KeyDown()
        };
        document.onselectstart = function () {
            return api_SelectStart()
        };
        document.oncontextmenu = function () {
            try {
                return api_ContextMenu()
            } catch (e) {
                return true
            }
        }
    };

function getdomainfromurl(v) {
        try {
            return v.split('http://')[1].split('/')[0]
        } catch (e) {
            return v
        }
    };

function book_FilterJson(v) {
        return v.replace(/[\r\n\xa0]/gi, '')
    };

function book_FilterText(v) {
        return v.replace(/()/gi, '').replace(/<br[^>]*>/gi, '\r\n').replace(/(\xa0)|(<[^>]+>)/gi, '')
    };

function book_FormatText(v) {
        return v.replace(/\r\n/gi, '<p style="margin-top:15px"></p>')
    };

function _setCookie(name, value, expiry, path, domain, secure) {
        var nameString = name + "=" + value;
        var expiryString = "";
        if (expiry != null) {
            try {
                expiryString = "; expires=" + expiry.toGMTString()
            } catch (e) {
                if (expiry) {
                    var lsd = new Date();
                    lsd.setTime(lsd.getTime() + expiry * 1000);
                    expiryString = "; expires=" + lsd.toGMTString()
                }
            }
        };
        var pathString = (path == null) ? " ;path=/" : " ;path = " + path;
        var domainString = (domain == null) ? "" : " ;domain = " + domain;
        var secureString = (secure) ? ";secure=" : "";
        document.cookie = nameString + expiryString + pathString + domainString + secureString;
    };

function _getCookie(name) {
        var CookieFound = false,
            start = 0,
            end = 0,
            CookieString = document.cookie;
        var i = 0;
        while (i <= CookieString.length) {
                start = i;
                end = start + name.length;
                if (CookieString.substring(start, end + 1) == (name + '=')) {
                    CookieFound = true;
                    break;
                };
                i++;
            };
        if (CookieFound) {
                start = end + 1;
                end = CookieString.indexOf(";", start);
                if (end < start) end = CookieString.length;
                return unescape(CookieString.substring(start, end));
            };
        return "";
    };

function setCookie(name, value, expiry, path, domain, secure) {
        if (expiry == null) expiry = 365 * 24 * 3600 * 1000;
        return _setCookie(name, escape(value), expiry, path, domain, secure)
    };

function getCookie(name) {
        return unescape(_getCookie(name))
    };

function errimg(obj) {
        if (obj.getAttribute('img_error') != null) return;
        obj.setAttribute('img_error', 1);
        obj.src = 'images\\booknopic.jpg';
    };

function _$() {
        return document.getElementById(arguments[0])
    };

function _$$() {
        return document.getElementsByName(arguments[0])
    };

function getSearch() {
        try {
            var url = dechar(location.search).replace(/&amp;/g, '#'),
                i;
            var lss = url.substr(url.indexOf('?') + 1).split('&');
            for (i = 0; i < lss.length; i++) if (lss[i].toLowerCase().indexOf(arguments[0].toLowerCase() + '=') == 0) return decodeURIComponent(lss[i].substr(lss[i].indexOf('=') + 1).replace(/\#/g, '&amp;'));
        } catch (e) {}
        return '';
    };

function enchar(v) {
        return encodeURIComponent(v)
    };

function dechar(v) {
        return decodeURIComponent(v)
    };

function hxmlchar(v) {
        return v.replace(/[\r\n]/gi, '').replace(/[&]/gi, '&amp;').replace(/["]/gi, '&quot;').replace(/[<]/gi, '&lt;').replace(/[>]/gi, '&gt;')
    };

function jschar(v) {
        return v.replace(/[\\]/gi, "\\\\").replace(/[']/gi, "\\'").replace(/["]/gi, '\\"').replace(/[\r]/gi, '\\r').replace(/[\n]/gi, '\\n')
    };

function getnode(item, name, value) {
        try {
            return item.getElementsByTagName(name)[0].firstChild.data
        } catch (e) {
            return value
        }
    };

function setnode(item, name, value) {
        try {
            item.getElementsByTagName(name)[0].firstChild.data = value;
        } catch (e) {
            try {
                var node = myxml.createElement(name),
                    cdata = myxml.createCDATASection(value);
                node.appendChild(cdata);
                item.appendChild(node);
            } catch (e) {
                return false
            }
        }
        return true;
    };

function getattribute(item, id, value) {
        var v;
        try {
            v = item.getAttribute(id)
        } catch (e) {};
        if (v == null) try {
            v = item.attributes.getNamedItem(id).firstChild.data
        } catch (e) {
            v = value
        }
        return v
    };

function trim() {
        return arguments[0].replace(/^\s+|\s+$/g, "")
    };

function left(str, n) {
        if (!str || !n) return '';
        var a = 0,
            i = 0,
            e = '...',
            t = '',
            t2 = '';
        for (i = 0; i < str.length; i++) {
                if (str.charCodeAt(i) > 255) a += 2;
                else a++;
                if (a > n - e.length && t2 == '') t2 = t;
                if (a > n) return str.length > t.length ? t2 + e : t;
                t += str.charAt(i)
            }
        return str
    };

function loadxml_file(v) {
        try {
            var xml = new ActiveXObject("MSXML2.DOMDocument");
            if (xml.load(v)) return xml.xml == '' ? null : xml;
        } catch (e) {
            return null
        }
    };

function loadxml(v) {
        try {
            var xml = new ActiveXObject("MSXML2.DOMDocument");
            if (xml.loadXML(v)) return xml;
        } catch (e) {
            try {
                var oParser = new DOMParser();
                xmlDom = oParser.parseFromString(v, "text/xml");
                return xmlDom;
            } catch (e) {}
        }
        return null;
    };

function readfile(fjname, charset) {
        try {
            if (charset == null) charset = config.charset;
            return external.fso_read(fjname, charset)
        } catch (e) {
            return ''
        }
    };

function writefile(fjname, value, charset) {
        try {
            if (charset == null) charset = config.charset;
            return external.fso_write(fjname, value, charset)
        } catch (e) {
            return '0'
        }
    };

function copyfile(fjname, fjname2) {
        try {
            return external.fso_copy(fjname, fjname2)
        } catch (e) {
            return '0'
        }
    };

function movefile(fjname, fjname2) {
        try {
            return external.fso_move(fjname, fjname2)
        } catch (e) {
            return '0'
        }
    };

function deletefile(fjname) {
        try {
            return external.fso_delete(fjname)
        } catch (e) {
            return '0'
        }
    };

function rmdir(path) {
        path = trim(path);
        if (path == '') return '0';
        try {
            return external.fso_rmdir(path)
        } catch (e) {
            return '0'
        }
    };

function getversion(file) {
        var ver = '';
        try {
            ver = external.getversion(file)
        } catch (e) {};
        return ver
    };

function calcver(v) {
        if (v == null) v = '';
        v += '.0.0.0.0';
        var u = '';
        var l = v.split('.');
        for (var i = 0; i < 4; i++) {
            var c = '00000' + l[i];
            u += c.substr(c.length - 5);
        };
        return u;
    };

function ini_read(file, section, key) {
        try {
            return external.ini_read(file, section, key)
        } catch (e) {}
    };

function ini_write(file, section, key, value) {
        try {
            return external.ini_write(file, section, key, value)
        } catch (e) {}
    };
var net_object = new Object();

function net_read(pid, func, url, head, info, charset, fjname) {
        if (pid == null) pid = parseInt(Math.random() * 9999999).toString();
        if (head == null) head = _userAgent;
        if (info == null) info = '';
        if (charset == null) charset = '936';
        if (fjname == null) fjname = '';
        try {
            net_object[pid] = func;
            return external.net_read(pid, url, head, info, charset, fjname);
        } catch (e) {}
    };

function net_recv(pid, data) {
        try {
            if (data.substr(0, 5) == 'cache') {
                var xml = loadxml_file(data),
                    fj = data;
                if (xml != null) data = getnode(xml, 'data', '');
                else data = '';
                deletefile(fj);
            }
            eval(net_object[pid].replace(/\{text\}/gi, "'" + jschar(data) + "'"));
        } catch (e) {}
    }; /*Json*/
if (typeof JSON !== 'object') {
        JSON = {}
    }(function () {
        'use strict';

        function f(n) {
            return n < 10 ? '0' + n : n
        }
        if (typeof Date.prototype.toJSON !== 'function') {
            Date.prototype.toJSON = function (key) {
                return isFinite(this.valueOf()) ? this.getUTCFullYear() + '-' + f(this.getUTCMonth() + 1) + '-' + f(this.getUTCDate()) + 'T' + f(this.getUTCHours()) + ':' + f(this.getUTCMinutes()) + ':' + f(this.getUTCSeconds()) + 'Z' : null
            };
            String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function (key) {
                return this.valueOf()
            }
        }
        var cx, escapable, gap, indent, meta, rep;

        function quote(string) {
            escapable.lastIndex = 0;
            return escapable.test(string) ? '"' + string.replace(escapable, function (a) {
                var c = meta[a];
                return typeof c === 'string' ? c : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4)
            }) + '"' : '"' + string + '"'
        }
        function str(key, holder) {
            var i, k, v, length, mind = gap,
                partial, value = holder[key];
            if (value && typeof value === 'object' && typeof value.toJSON === 'function') {
                    value = value.toJSON(key)
                }
            if (typeof rep === 'function') {
                    value = rep.call(holder, key, value)
                }
            switch (typeof value) {
                case 'string':
                    return quote(value);
                case 'number':
                    return isFinite(value) ? String(value) : 'null';
                case 'boolean':
                case 'null':
                    return String(value);
                case 'object':
                    if (!value) {
                        return 'null'
                    }
                    gap += indent;
                    partial = [];
                    if (Object.prototype.toString.apply(value) === '[object Array]') {
                        length = value.length;
                        for (i = 0; i < length; i += 1) {
                            partial[i] = str(i, value) || 'null'
                        }
                        v = partial.length === 0 ? '[]' : gap ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']' : '[' + partial.join(',') + ']';
                        gap = mind;
                        return v
                    }
                    if (rep && typeof rep === 'object') {
                        length = rep.length;
                        for (i = 0; i < length; i += 1) {
                            k = rep[i];
                            if (typeof k === 'string') {
                                v = str(k, value);
                                if (v) {
                                    partial.push(quote(k) + (gap ? ': ' : ':') + v)
                                }
                            }
                        }
                    } else {
                        for (k in value) {
                            if (Object.prototype.hasOwnProperty.call(value, k)) {
                                v = str(k, value);
                                if (v) {
                                    partial.push(quote(k) + (gap ? ': ' : ':') + v)
                                }
                            }
                        }
                    }
                    v = partial.length === 0 ? '{}' : gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}' : '{' + partial.join(',') + '}';
                    gap = mind;
                    return v
                }
        }
        if (typeof JSON.stringify !== 'function') {
            escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            meta = {
                '\b': '\\b',
                '\t': '\\t',
                '\n': '\\n',
                '\f': '\\f',
                '\r': '\\r',
                '"': '\\"',
                '\\': '\\\\'
            };
            JSON.stringify = function (value, replacer, space) {
                var i;
                gap = '';
                indent = '';
                if (typeof space === 'number') {
                    for (i = 0; i < space; i += 1) {
                        indent += ' '
                    }
                } else if (typeof space === 'string') {
                    indent = space
                }
                rep = replacer;
                if (replacer && typeof replacer !== 'function' && (typeof replacer !== 'object' || typeof replacer.length !== 'number')) {
                    throw new Error('JSON.stringify')
                }
                return str('', {
                    '': value
                })
            }
        }
        if (typeof JSON.parse !== 'function') {
            cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            JSON.parse = function (text, reviver) {
                var j;

                function walk(holder, key) {
                    var k, v, value = holder[key];
                    if (value && typeof value === 'object') {
                        for (k in value) {
                            if (Object.prototype.hasOwnProperty.call(value, k)) {
                                v = walk(value, k);
                                if (v !== undefined) {
                                    value[k] = v
                                } else {
                                    delete value[k]
                                }
                            }
                        }
                    }
                    return reviver.call(holder, key, value)
                }
                text = String(text);
                cx.lastIndex = 0;
                if (cx.test(text)) {
                    text = text.replace(cx, function (a) {
                        return '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4)
                    })
                }
                if (/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
                    j = eval('(' + text + ')');
                    return typeof reviver === 'function' ? walk({
                        '': j
                    }, '') : j
                }
                throw new SyntaxError('JSON.parse')
            }
        }
        if (!Object.prototype.toJSONString) {
            Object.prototype.toJSONString = function (filter) {
                return JSON.stringify(this, filter)
            };
            Object.prototype.parseJSON = function (filter) {
                return JSON.parse(this, filter)
            }
        }
    }());

function String2Json(v) {
        return eval('(' + v + ')')
    };

function Json2String(v) {
        return v.toJSONString()
    }; /*Md5*/
var hexcase = 0;
var b64pad = "";
var chrsz = 8;

function hex_md5(s) {
        return binl2hex(core_md5(str2binl(s), s.length * chrsz))
    }
function b64_md5(s) {
        return binl2b64(core_md5(str2binl(s), s.length * chrsz))
    }
function hex_hmac_md5(key, data) {
        return binl2hex(core_hmac_md5(key, data))
    }
function b64_hmac_md5(key, data) {
        return binl2b64(core_hmac_md5(key, data))
    }
function calcMD5(s) {
        return binl2hex(core_md5(str2binl(s), s.length * chrsz))
    }
function md5_vm_test() {
        return hex_md5("abc") == "900150983cd24fb0d6963f7d28e17f72"
    }
function core_md5(x, len) {
        x[len >> 5] |= 0x80 << ((len) % 32);
        x[(((len + 64) >>> 9) << 4) + 14] = len;
        var a = 1732584193;
        var b = -271733879;
        var c = -1732584194;
        var d = 271733878;
        for (var i = 0; i < x.length; i += 16) {
            var olda = a;
            var oldb = b;
            var oldc = c;
            var oldd = d;
            a = md5_ff(a, b, c, d, x[i + 0], 7, -680876936);
            d = md5_ff(d, a, b, c, x[i + 1], 12, -389564586);
            c = md5_ff(c, d, a, b, x[i + 2], 17, 606105819);
            b = md5_ff(b, c, d, a, x[i + 3], 22, -1044525330);
            a = md5_ff(a, b, c, d, x[i + 4], 7, -176418897);
            d = md5_ff(d, a, b, c, x[i + 5], 12, 1200080426);
            c = md5_ff(c, d, a, b, x[i + 6], 17, -1473231341);
            b = md5_ff(b, c, d, a, x[i + 7], 22, -45705983);
            a = md5_ff(a, b, c, d, x[i + 8], 7, 1770035416);
            d = md5_ff(d, a, b, c, x[i + 9], 12, -1958414417);
            c = md5_ff(c, d, a, b, x[i + 10], 17, -42063);
            b = md5_ff(b, c, d, a, x[i + 11], 22, -1990404162);
            a = md5_ff(a, b, c, d, x[i + 12], 7, 1804603682);
            d = md5_ff(d, a, b, c, x[i + 13], 12, -40341101);
            c = md5_ff(c, d, a, b, x[i + 14], 17, -1502002290);
            b = md5_ff(b, c, d, a, x[i + 15], 22, 1236535329);
            a = md5_gg(a, b, c, d, x[i + 1], 5, -165796510);
            d = md5_gg(d, a, b, c, x[i + 6], 9, -1069501632);
            c = md5_gg(c, d, a, b, x[i + 11], 14, 643717713);
            b = md5_gg(b, c, d, a, x[i + 0], 20, -373897302);
            a = md5_gg(a, b, c, d, x[i + 5], 5, -701558691);
            d = md5_gg(d, a, b, c, x[i + 10], 9, 38016083);
            c = md5_gg(c, d, a, b, x[i + 15], 14, -660478335);
            b = md5_gg(b, c, d, a, x[i + 4], 20, -405537848);
            a = md5_gg(a, b, c, d, x[i + 9], 5, 568446438);
            d = md5_gg(d, a, b, c, x[i + 14], 9, -1019803690);
            c = md5_gg(c, d, a, b, x[i + 3], 14, -187363961);
            b = md5_gg(b, c, d, a, x[i + 8], 20, 1163531501);
            a = md5_gg(a, b, c, d, x[i + 13], 5, -1444681467);
            d = md5_gg(d, a, b, c, x[i + 2], 9, -51403784);
            c = md5_gg(c, d, a, b, x[i + 7], 14, 1735328473);
            b = md5_gg(b, c, d, a, x[i + 12], 20, -1926607734);
            a = md5_hh(a, b, c, d, x[i + 5], 4, -378558);
            d = md5_hh(d, a, b, c, x[i + 8], 11, -2022574463);
            c = md5_hh(c, d, a, b, x[i + 11], 16, 1839030562);
            b = md5_hh(b, c, d, a, x[i + 14], 23, -35309556);
            a = md5_hh(a, b, c, d, x[i + 1], 4, -1530992060);
            d = md5_hh(d, a, b, c, x[i + 4], 11, 1272893353);
            c = md5_hh(c, d, a, b, x[i + 7], 16, -155497632);
            b = md5_hh(b, c, d, a, x[i + 10], 23, -1094730640);
            a = md5_hh(a, b, c, d, x[i + 13], 4, 681279174);
            d = md5_hh(d, a, b, c, x[i + 0], 11, -358537222);
            c = md5_hh(c, d, a, b, x[i + 3], 16, -722521979);
            b = md5_hh(b, c, d, a, x[i + 6], 23, 76029189);
            a = md5_hh(a, b, c, d, x[i + 9], 4, -640364487);
            d = md5_hh(d, a, b, c, x[i + 12], 11, -421815835);
            c = md5_hh(c, d, a, b, x[i + 15], 16, 530742520);
            b = md5_hh(b, c, d, a, x[i + 2], 23, -995338651);
            a = md5_ii(a, b, c, d, x[i + 0], 6, -198630844);
            d = md5_ii(d, a, b, c, x[i + 7], 10, 1126891415);
            c = md5_ii(c, d, a, b, x[i + 14], 15, -1416354905);
            b = md5_ii(b, c, d, a, x[i + 5], 21, -57434055);
            a = md5_ii(a, b, c, d, x[i + 12], 6, 1700485571);
            d = md5_ii(d, a, b, c, x[i + 3], 10, -1894986606);
            c = md5_ii(c, d, a, b, x[i + 10], 15, -1051523);
            b = md5_ii(b, c, d, a, x[i + 1], 21, -2054922799);
            a = md5_ii(a, b, c, d, x[i + 8], 6, 1873313359);
            d = md5_ii(d, a, b, c, x[i + 15], 10, -30611744);
            c = md5_ii(c, d, a, b, x[i + 6], 15, -1560198380);
            b = md5_ii(b, c, d, a, x[i + 13], 21, 1309151649);
            a = md5_ii(a, b, c, d, x[i + 4], 6, -145523070);
            d = md5_ii(d, a, b, c, x[i + 11], 10, -1120210379);
            c = md5_ii(c, d, a, b, x[i + 2], 15, 718787259);
            b = md5_ii(b, c, d, a, x[i + 9], 21, -343485551);
            a = safe_add(a, olda);
            b = safe_add(b, oldb);
            c = safe_add(c, oldc);
            d = safe_add(d, oldd)
        }
        return Array(a, b, c, d)
    }
function md5_cmn(q, a, b, x, s, t) {
        return safe_add(bit_rol(safe_add(safe_add(a, q), safe_add(x, t)), s), b)
    }
function md5_ff(a, b, c, d, x, s, t) {
        return md5_cmn((b & c) | ((~b) & d), a, b, x, s, t)
    }
function md5_gg(a, b, c, d, x, s, t) {
        return md5_cmn((b & d) | (c & (~d)), a, b, x, s, t)
    }
function md5_hh(a, b, c, d, x, s, t) {
        return md5_cmn(b ^ c ^ d, a, b, x, s, t)
    }
function md5_ii(a, b, c, d, x, s, t) {
        return md5_cmn(c ^ (b | (~d)), a, b, x, s, t)
    }
function core_hmac_md5(key, data) {
        var bkey = str2binl(key);
        if (bkey.length > 16) bkey = core_md5(bkey, key.length * chrsz);
        var ipad = Array(16),
            opad = Array(16);
        for (var i = 0; i < 16; i++) {
                ipad[i] = bkey[i] ^ 0x36363636;
                opad[i] = bkey[i] ^ 0x5C5C5C5C
            }
        var hash = core_md5(ipad.concat(str2binl(data)), 512 + data.length * chrsz);
        return core_md5(opad.concat(hash), 512 + 128)
    }
function safe_add(x, y) {
        var lsw = (x & 0xFFFF) + (y & 0xFFFF);
        var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
        return (msw << 16) | (lsw & 0xFFFF)
    }
function bit_rol(num, cnt) {
        return (num << cnt) | (num >>> (32 - cnt))
    }
function str2binl(str) {
        var bin = Array();
        var mask = (1 << chrsz) - 1;
        for (var i = 0; i < str.length * chrsz; i += chrsz) bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << (i % 32);
        return bin
    }
function binl2hex(binarray) {
        var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
        var str = "";
        for (var i = 0; i < binarray.length * 4; i++) {
            str += hex_tab.charAt((binarray[i >> 2] >> ((i % 4) * 8 + 4)) & 0xF) + hex_tab.charAt((binarray[i >> 2] >> ((i % 4) * 8)) & 0xF)
        }
        return str
    }
function binl2b64(binarray) {
        var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        var str = "";
        for (var i = 0; i < binarray.length * 4; i += 3) {
            var triplet = (((binarray[i >> 2] >> 8 * (i % 4)) & 0xFF) << 16) | (((binarray[i + 1 >> 2] >> 8 * ((i + 1) % 4)) & 0xFF) << 8) | ((binarray[i + 2 >> 2] >> 8 * ((i + 2) % 4)) & 0xFF);
            for (var j = 0; j < 4; j++) {
                if (i * 8 + j * 6 > binarray.length * 32) str += b64pad;
                else str += tab.charAt((triplet >> 6 * (3 - j)) & 0x3F)
            }
        }
        return str
    }; /*common*/


function c_jstime(s) {
        if (s == "999") {
            main.jstime_u = new Array();
            main.jstime_t = new Date();
            return
        };
        if (s == "888") {
            alert(main.jstime_u.join('\r\n'));
            return
        };
        var _u = new Date();
        main.jstime_u.push(s + ',' + (_u - main.jstime_t));
        main.jstime_t = _u;
    };

function c_syncdata() {
        main.act_his = calcMD5(readfile(config.his));
        main.act_fav = calcMD5(readfile(config.fav));
    };

function c_filejson(f) {
        try {
            return String2Json(readfile(f))
        } catch (e) {}
    };

function c_strjson(f) {
        try {
            return String2Json(f)
        } catch (e) {}
    };

function c_tips(act, func, info, n) {
	alert("tips");
        var t = _$('tips'),
            ti = _$('tips_info');
        switch (act) {
            case 'click':
                c_tips('hide');
                if (func == 'yes') try {
                    eval(main.tips_func)
                } catch (e) {};
                break;
            case 'show':
                ti.innerHTML = '<i class="del"></i>' + info + '<div class="btnbox"><a onfocus=this.blur() href="#" onmouseover="this.className=\'onclick\'" onmouseout="this.className=\'\'" onclick="c_tips(\'click\',\'yes\');return false">是（Y）</a>' + (n > 1 ? '<a onfocus=this.blur() href="#" onmouseover="this.className=\'onclick\'" onmouseout="this.className=\'\'" onclick="c_tips(\'click\',\'no\');return false">否（N）</a>' : '') + '</div>';
                ti.setAttribute('_his', info.indexOf('阅读记录') > 0 ? '1' : '0');
                t.style.display = '';
                main.tips_func = func;
                if (ti.getAttribute('_his') == '1') {
                    var tih = _$$('h_his_delbs');
                    for (var i = 0; i < tih.length; i++) tih[i].style.display = '';
                };
                break;
            case 'hide':
                t.style.display = 'none';
                if (ti.getAttribute('_his') == '1') {
                    var tih = _$$('h_his_delbs');
                    for (var i = 0; i < tih.length; i++) tih[i].style.display = 'none';
                };
                break;
            };
    };

function c_operHisFav(s, act, db, s2) {
        var file = _path + '\\' + s,
            l = 500,
            nr = readfile(file),
            w;
        if (nr == '') nr = '{"db":[]}';
        w = c_strjson(nr);
        if (w == null) return;
        if (s == 'his') l = 20;
        switch (act) {
            case 'add':
                var bookid = db.bookid,
                    path = _path + '\\' + bookid + '\\';
                for (var i = 0; i < w.db.length; i++) {
                        if (w.db[i] == bookid) w.db.splice(i, 1);
                    };
                if (s == 'his') db.his = 1;
                else db.fav = 1;
                db.updatetime = time_func();
                r_savebook(db);
                w.db.push(bookid);
                while (w.db.length > l) {
                        c_operHisFav(s, 'del', w.db.splice(0, 1), 1);
                    };
                c_operHisFav(s, 'save', w);
                if (s == 'fav') return '0';
                break;
            case 'save':
                if (main.pType == '1') r_updateButton();
                s2 = Json2String(db);
                setCookie('act_' + s, calcMD5(s2));
                writefile(file, s2);
                break;
            case 'del':
                var dbs = db.toString().split(',');
                for (var i = 0; i < w.db.length; i++) {
                        for (var j = 0; j < dbs.length; j++) {
                            var bookid = dbs[j];
                            if (w.db[i] == bookid) {
                                var path = _path + '\\' + w.db.splice(i, 1);
                                var db = c_filejson(path + '\\main');
                                if (db == null) continue;
                                if (s == 'his') db.his = 0;
                                if (s == 'fav') db.fav = 0;
                                if (db.his == 0 && db.fav == 0) rmdir(path);
                                else writefile(path + '\\main', Json2String(db));
                            };
                        };
                    };
                if (s2 == null) c_operHisFav(s, 'save', w);
                break;
            case 'kill':
                while (w.db.length > 0) {
                        c_operHisFav(s, 'del', w.db.splice(0, 1), 1);
                    };
                c_operHisFav(s, 'save', w);
                break;
            };
    }; /*home*/


function h_changeMenu(m) {
        var isb = typeof(m) == 'object';
        main.curMenu_old = main.curMenu;
        if (isb) m = m.getAttribute('_i');
        var menus = _$$('h_menus');
        for (var i = 0; i < menus.length; i++) {
            var _i = menus[i].getAttribute('_i'),
                isme = m == _i;
            menus[i].className = (isme ? menus[i].getAttribute('_focus') : menus[i].getAttribute('_blur'));
            switch (true) {
                case _i.substr(0, 1) == '4':
                    var _j = parseInt(_i.substr(1));
                    if (isme) main.menu_cate.l[_j].getElementsByTagName('a')[0].click();
                    _i = _i.substr(0, 1);
                    break;
                case isme && m == 2:
                    main.timer_his = window.setTimeout("h_loaddata('his')", 100);
                    break;
                };
            _$('h_menu_' + _i).style.display = (isme ? 'block' : 'none');
            if (!isme) continue;
            main.curMenu = m;
            if (m == 0) {
                    var e = _$$('h_search');
                    e[_$('h_menu_0_1').style.display == 'none' ? 4 : 3].focus()
                };
        };
        m = m + '';
        var n = parseInt(m.substr(0, 1));
        if (n == 4) _$('h_menu_4').style.display = '';
        if (n != 1) try {
            _$('h_menu_' + n).focus()
        } catch (e) {};
    };

function h_OpenBook(obj, offset) {
        if (typeof(obj) == 'string') obj = _$(obj);
        var bookid = obj.getAttribute('_bookid'),
            local = obj.getAttribute('_local'),
            url;
        if (offset == null) offset = obj.getAttribute('_offset');
        if (offset == null) offset = -1;
        if (local == '1') {
                url = 'home.html?ptype=1&bookid=' + bookid + '&local=' + local + '&offset=' + offset;
            } else {
                var _json = dechar(obj.getAttribute('_json')),
                    db = c_strjson(_json);
                var file = 'jh_' + parseInt(Math.random() * 99999),
                    stype = obj.getAttribute('_stype'),
                    from = obj.getAttribute('_from');
                setCookie(file, _json, 60);
                url = 'home.html?ptype=1&bookid=' + bookid + '&stype=' + stype + '&from=' + from + '&local=' + local + '&offset=' + offset + '&file=' + file
            };
        if (offset != null) setCookie('act_' + bookid, '{"act":"offset","offset":' + offset + '}');
        api_OpenTab(bookid, url);
    };

function h_Search(act, key, page, text) {
        var m1 = _$('h_menu_0_1'),
            m2 = _$('h_menu_0_2'),
            m2d = _$('h_menu_0_2_data');
        switch (act) {
            case 'get':
                if (main.curMenu != 0) h_changeMenu(0);
                if (key == null) key = '';
                if (page == null) page = 1;
                main.Search = new Array(key, page);
                net_read(null, 'h_Search("recv","' + jschar(key) + '",' + page + ',{text})', 'http://book.easou.com/ta/searchMoreBoosAjax.m?page=' + page + '&word=' + enchar(key) + '', null, null, '65001');
                if (page == 1) {
                    var e = _$$('h_search');
                    for (var i = 0; i < e.length; i++) e[i].value = key;
                    m1.style.display = 'none';
                    m2d.innerHTML = '<div class="schres" style="display:none"></div><div>正在加载中,请稍候...</div><div class="page" style="display:none"></div>';
                    m2.style.display = ''
                }
                else m2d.innerHTML = '正在加载中,请稍候...';
                break;
            case 'recv':
                if (main.Search[0] != key && main.Search[1] != page) return;
                var obj = c_strjson(text);
                if (obj == null) {
                    m2d.innerHTML = '很抱歉，没有找到相关的数据!';
                    return
                };
                var pt = obj.totalPage,
                    ps = 0,
                    pn = obj.page,
                    tn = obj.total,
                    list = obj,
                    nr = new Array();
                nr.push('<div class="schres"><strong>搜索<span>“' + key + '”</span>的结果：</strong>以下搜索结果是来自搜狗、百度、一搜等搜索引擎</div>');
                nr.push('<table border="0" cellspacing="0" cellpadding="0" class="list searchlist">');
                for (var i = 0; i < list.length; i++) {
                        var b = list,
                            b2 = {};
                        try {
                                b2.bkey = "";
                                b2.book = book_FilterText(b[i].novelName || b[i].name);
                                b2.author = book_FilterText(b[i].author);
                                b2.type = b[i].classes;
                                b2.desc = b[i].description || b[i].desc;
                                b2.url = b[i].fromWeb;
                                b2.chapter = b[i].lastChapterName;
                                b2.chapterurl = b[i].fromWeb;
                                b2.chaptermd5 = "";
                                b2.chaptercid = b[i].chapterNum;
                                b2.site = b[i].fromWeb;
                                b2.date = 0;
                                b2.chapterNum = b[i].chapterCount;
                                b2.id = b[i].enid;
                                b2.md = b[i].nid;
                                b2.loc = 1;
                                b2.sourceNum = parseInt(Math.random() * 99);
                                b2.nameMD5 = '';
                                b2.authorMD5 = '';
                                b2.status = (b[i].attribute == '全本' ? '1' : '0');
                                b2.picurl = b[i].imgUrl || b[i].imgurl
                            } catch (e) {
                                continue
                            };
                        if (b2.md == '') continue;
                        list[i].novelName = book_FilterText(list[i].novelName);
                        if (list[i].nid == '') continue;
                        var pid = '_' + parseInt(Math.random() * 999999999);
                        nr.push('<tr id="' + pid + '" _bookid="' + (calcMD5(list[i].novelName + '__' + list[i].author)) + '" _stype="web" _from="sogou" _local="0" _offset="-1" _json="' + enchar(Json2String(b2)) + '">');
                        nr.push('<td class="infostd">');
                        nr.push('<h4><a href="#" onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + list[i].novelName + '-' + list[i].author + '[' + list[i].classes + ']</a><span style="display:' + (list[i].loc == 0 ? 'none' : '') + '" class="res-flag">优质结果</span></h4>');
                        nr.push('<p>' + left(list[i].description, 200) + '</p>');
                        nr.push('<p>最新章节：<a onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\',-1);return false">' + list[i].lastChapterName + '</a>   <span class="green">' + '' + '</span></p>');
                        nr.push('<p style="visibility:hidden"><span class="green">最佳来源：</span><a onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">共' + list[i].sourceNum + '个来源网站</a></p>');
                        nr.push('</td>');
                        nr.push('<td><span class="red">' + (list[i].attribute != '全本' ? '连载中' : '已完结') + '</span></td>');
                        nr.push('<td><a href="#" class="button" onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">立即查看</a></td>');
                        nr.push('</tr>');
                    };
                var m = new Array();
                var p = page,
                    p_max = obj.totalPage;
                m.push('<div class="page">');
                if (p_max > 1 && p > 1) m.push('<a onfocus=this.blur() href="#" onclick="h_Search(\'get\',\'' + key + '\',' + 1 + ');return false">首页</a><a onfocus=this.blur() href="#" onclick="h_Search(\'get\',\'' + key + '\',' + (p - 1) + ');return false">上一页</a>');
                else m.push('<span>首页</span><span>上一页</span>');
                var x = p - 3,
                    y = p + 3;
                if (x < 0) y += Math.abs(x);
                if (y > p_max) x -= y - p_max,
                y = p_max;
                if (x < 1) x = 1;
                for (var i = x; i <= y; i++) {
                        if (i == p) m.push('<strong>' + i + '</strong>');
                        else m.push('<a href="#" onclick="h_Search(\'get\',\'' + key + '\',' + i + ');return false" onfocus=this.blur()>' + i + '</a>');
                    };
                if (p_max > 1 && p < p_max) m.push('<a onfocus=this.blur() href="#" onclick="h_Search(\'get\',\'' + key + '\',' + (p + 1) + ');return false">下一页</a><a onfocus=this.blur() href="#" onclick="h_Search(\'get\',\'' + key + '\',' + (p_max) + ');return false">尾页</a>');
                else m.push('<span>下一页</span><span>尾页</span>');
                m.push('</div>');
                nr.push('</table>');
                nr.push(m.join(''));
                m2d.innerHTML = nr.join('');
                m2d.focus();
                break;
            };
    };

function h_Search_Input(s) {
        var e = event.srcElement.parentNode.getElementsByTagName('input');
        if (s == 1) {
            if (event.keyCode == 13) e[1].click();
        } else {
            var v = e[0].value;
            if (v != '' && v.indexOf(config.defaultkey) < 0) h_Search('get', v);
        }
    };

function h_ContextMenu() {
        var e = event.srcElement;
        if (e.tagName == 'INPUT' || e.tagName == 'TEXTAREA') return true;
        return false;
    };

function h_resize(w, h) {
        if (w == null) w = document.documentElement.clientWidth,
        h = document.documentElement.clientHeight;
        _$('scroll_home').style.height = (h - 38) + 'px';
        _$('scroll_home_right').style.height = h + 'px';
        _$('h_menu_1').style.width = (w - 210) + 'px';
        var w2 = w - 210,
            li = _$('h_shelf').getElementsByTagName('LI'),
            liw = 160,
            lin = parseInt(w2 / liw),
            lir = 20;
        if (li.length > lin) lir = parseInt((w2 - lin * liw) / lin) + lir;
        for (var i = 0; i < li.length; i++) li[i].style.marginRight = lir + 'px';
    };

function h_update(act) {
        return;
        if (main.update == null) main.update = new Object();
        switch (act) {
        case 'reset':
            window.clearTimeout(main.update.timer);
            main.update.timer = window.setTimeout('h_update()', 1800 * 1000);
            break;
        case 'list':
            try {
                var db = c_filejson(config.fav).db
            } catch (e) {
                return
            };
            for (var i = db.length - 1; i >= 0; i--) {
                var b2 = c_filejson(_path + '\\' + db[i] + '\\main');
                if (b2 == null) continue;
                if (b2.status == '0') try {
                    var s = _$('h_book_' + db[i] + '_have');
                    s.className = b2.have == 1 ? s.getAttribute('_have') : '';
                    s = _$('h_book_' + db[i] + '_info');
                    s.innerHTML = '<h3> <a href="#" onfocus=this.blur() onclick="return false">' + time_func(b2.updatetime) + '</a></h3><div> <a href="#" onfocus=this.blur() onclick="return false">' + (b2.chapter.length > 0 ? b2.chapter[b2.chapter.length - 1].name : '') + '</a></div>';
                } catch (e) {};
            };
            break;
        case 'over':
            h_update('reset');
            var task = main.update.task,
                have = 0;
            for (var i = 0; i < task.length; i++) {
                    if (task[i][2] == 0) continue;
                    have = 1;
                    var f = readfile(_path + '\\' + task[i][0] + '\\main');
                    if (f == '') continue;
                    var b = c_strjson(f);
                    b.have = 1;
                    b.chapter = task[i][3];
                    b.updatetime = time_func();
                    b.update = b.chapter.length - 1;
                    r_savebook(b);
                    setCookie('act_' + task[i][0], '{"act":"have"}');
                };
            if (have == 1) h_update('list');
            h_update('reset');
            break;
        case 'get':
            net_read(null, 'h_update("recv",{text})', main.update.task[main.update.task_i][1], null, null, '936');
            break;
        case 'recv':
            try {
                    var b = c_strjson(arguments[1]);
                    switch (b.update) {
                    case 'all':
                        main.update.task[main.update.task_i][2] = 1;
                        main.update.task[main.update.task_i][3] = b.chapter;
                        break;
                    case 'append':
                        main.update.task[main.update.task_i][1] = main.update.task[main.update.task_i][1].replace(/c[0-9]\./gi, '');
                        h_update('get');
                        return;
                        break;
                    };
                } catch (e) {};
            if (++main.update.task_i < main.update.task.length) h_update('get');
            else h_update('over');
            break;
        default:
            try {
                    var db = c_filejson(config.fav).db
                } catch (e) {
                    h_update('reset');
                    return
                };
            main.update.task = new Array();
            for (var i = db.length - 1; i >= 0; i--) {
                    var b = readfile(_path + '\\' + db[i] + '\\main');
                    if (b == '') continue;
                    var b2 = c_strjson(b);
                    if (b2.status == '0') {
                        var url = 'http://k.sogou.com/apt/app/menu?md=' + b2.md + '&eid=0&uid=&sdkandroid=2.3.7&versioncode=1321';
                        var chapter = b2.chapter,
                            b3 = 6;
                        for (j = chapter.length - 1; j >= 0; j--) {
                                url += '&c' + b3 + '.title=' + enchar(chapter[j].name) + '&c' + b3 + '.cmd=' + chapter[j].cmd;
                                if (--b3 <= 3) break;
                            };
                        main.update.task.push(new Array(b2.bookid, url, 0));
                    };
                };
            if (main.update.task.length == 0) {
                    h_update('reset');
                    return
                };
            main.update.task_i = 0;
            h_update('get');
            break;
        };
    };

function h_his_func(s, o) {
        switch (s) {
        case 'over':
            o = o.getElementsByTagName('input')[0];
            o.style.visibility = 'visible';
            break;
        case 'out':
            o = o.getElementsByTagName('input')[0];
            o.style.visibility = o.checked ? 'visible' : 'hidden';
            break;
        case 'click':
            _$('h_his_del').setAttribute('disabled', main.h_his_i > 0 ? null : 1);
            break;
        case 'del':
            o = _$('h_his_bookids');
            var l = _$$('h_his_input'),
                l2 = new Array();
            for (var i = l.length - 1; i >= 0; i--) {
                    if (l[i].checked) {
                        var o2 = _$(l[i].getAttribute('_id'));
                        l2.push(o2.getAttribute('_bookid'));
                        o2.parentNode.removeChild(o2);
                    };
                };
            main.h_his_i = 0;
            h_his_func('click');
            window.setTimeout(function () {
                    c_operHisFav('his', 'del', l2.join(','))
                }, 100);
            break;
        case 'killpre':
            c_tips('show', 'h_his_func("kill")', '确定要删除所有历史记录吗?', 2);
            break;
        case 'kill':
            o = _$('h_his_bookids');
            var l = _$$('h_his_input');
            for (var i = l.length - 1; i >= 0; i--) {
                    var o2 = _$(l[i].getAttribute('_id'));
                    o2.parentNode.removeChild(o2);
                };
            main.h_his_i = 0;
            h_his_func('click');
            window.setTimeout(function () {
                    c_operHisFav('his', 'kill')
                }, 100);
            break;
        };
    };

function h_loaddata(s) {
        var nr, db, mb;
        switch (s) {
        case 'his':
            window.clearTimeout(main.timer_his);
            nr = readfile(config.his);
            if (nr != '') {
                main.h_his_i = 0;
                db = c_strjson(nr).db;
                mb = new Array();
                mb.push('<div id="topbar"><a href="#" onfocus=this.blur() onclick="h_his_func(\'del\');return false" id="h_his_del" disabled class="btndel">删除所选记录</a><a href="#" onfocus=this.blur() onclick="h_his_func(\'killpre\');return false" class="btndel">删除所有记录</a></div>');
                mb.push('<table id="h_his_bookids" border="0" cellspacing="0" cellpadding="0" class="history">');
                for (var i = db.length - 1; i >= 0; i--) {
                    var b2 = c_filejson(_path + '\\' + db[i] + '\\main');
                    if (b2 == null) continue;
                    var pid = 'h_his_bookid_' + parseInt(Math.random() * 99999),
                        pid2 = "";
                    try {
                            var mb2 = new Array();
                            mb2.push('<tr onmouseover="h_his_func(\'over\',this)" onmouseout="h_his_func(\'out\',this)" id="' + pid + '" title="' + hxmlchar(b2.book + ' 作者:' + b2.author) + '" _book="' + hxmlchar(b2.book) + '" _bookid="' + b2.bookid + '" _local="1" title="' + hxmlchar(b2.book + ' 作者:' + b2.author) + '">');
                            mb2.push('<td><input onclick="if(this.checked) main.h_his_i++; else main.h_his_i--;h_his_func(\'click\')" _id="' + pid + '" id="h_his_input" style="visibility:hidden" onfocus=this.blur() type="checkbox" /></td>');
                            mb2.push('<td _t="' + (b2.lasttime == null ? time_func() : b2.lasttime) + '">' + time_func(b2.lasttime == null ? time_func() : b2.lasttime) + '</td>');
                            mb2.push('<td class="redhis"><a href="#" onfocus=this.blur() onclick="h_OpenBook(\'' + pid + '\');return false"><span class="blue">' + b2.book + '</span>读至：' + (b2.chapter[b2.offset].name || b2.chapter[b2.offset].chapterName) + '</a></td>');
                            mb2.push('</tr>');
                            mb.push(mb2.join(''));
                        } catch (e) {};
                };
                mb.push('</table>');
                _$('h_menu_2').innerHTML = mb.join('');
            };
        case 'fav':
            window.clearTimeout(main.timer_fav);
            nr = readfile(config.fav);
            if (nr != '') {
                db = c_strjson(nr).db;
                mb = new Array();
                var shelf = _$('h_shelf');
                for (var i = db.length - 1; i >= 0; i--) {
                    var b2 = c_filejson(_path + '\\' + db[i] + '\\main');
                    if (b2 == null) continue;
                    mb.push('<li id="h_book_' + b2.bookid + '" title="' + hxmlchar(b2.book + ' 作者:' + b2.author) + '" _book="' + hxmlchar(b2.book) + '" _bookid="' + b2.bookid + '" _local="1" onclick="var e=event.srcElement.outerHTML;if(e.indexOf(\'close\')>0) h_delfav(this); else h_OpenBook(this);">');
                    mb.push('<a onfocus=this.blur() href="#" onclick="return false">');
                    mb.push('<span id="h_book_' + b2.bookid + '_have" _have="flag"' + (b2.have == 1 ? ' class="flag"' : '') + '></span>');
                    mb.push('<i>' + b2.book + '</i>');
                    mb.push('<img src="' + b2.picurl + '" onerror="errimg(this)" width="122" height="152" /><span class="cover"></span>');
                    mb.push('<span id="h_book_close" class="closebtn" style="display:' + (main.fav_editmode == null ? 'none' : '') + '"></span>');
                    mb.push('</a>');
                    mb.push('</li>');
                };
                _$('h_shelf').innerHTML = mb.join('');
                _$('h_menu_1_1').style.display = db.length > 0 ? 'none' : '';
                _$('h_menu_1_1').style.visibility = db.length > 0 ? 'hidden' : 'visible';
                _$('h_menu_1_2').style.display = db.length > 0 ? '' : 'none';
                h_resize();
            };
        };
    };

function h_fav_editmode(o) {
        if (o == null) o = _$('h_fav_editbutton');
        var u = 'none',
            l = _$$('h_book_close');
        if (main.fav_editmode == null) u = '';
        for (var i = 0; i < l.length; i++) l[i].style.display = u;
        main.fav_editmode = u == '' ? 1 : null;
        o.innerHTML = u == '' ? '完成' : '编辑';
    };

function h_delfav(obj) {
        window.h_delfav2 = function () {
            var objp = obj.parentNode;
            objp.removeChild(obj);
            var li = objp.getElementsByTagName('li');
            if (li.length == 0) {
                if (main.fav_editmode != null) h_fav_editmode();
                _$('h_menu_1_1').style.display = '';
                _$('h_menu_1_1').style.visibility = 'visible';
                _$('h_menu_1_2').style.display = 'none'
            };
        };
        c_tips('show', 'window.h_delfav2();c_operHisFav("fav","del","' + obj.getAttribute('_bookid') + '")', '确定要删除《' + obj.getAttribute('_book') + '》吗?', 2);
    };

function h_menu_cate(act) {
        if (main.menu_cate == null) main.menu_cate = new Object();
        var l = main.menu_cate.l,
            m = new Array();
        switch (act) {
            case 'change':
                var j = arguments[1];
                if (j == null) j = 0;
                if (isNaN(j)) for (var i = 0; i < l.length; i++) if (l[i].getAttribute('_name') == j) {
                    j = i;
                    break
                };
                if (isNaN(j)) j = 0;
                if (main.menu_cate.curJ == j) return;
                main.menu_cate.curJ = j;
                for (var i = 0; i < l.length; i++) l[i].className = (i == j ? 'current' : '');
                _$('h_menu_cate_name').innerHTML = l[j].getAttribute('_name');
                h_menu_cate('get', j);
                break;
            case 'get':
                var j = arguments[1],
                    p = arguments[2];
                if (p == null) p = 1;
                main.menu_cate.j = j;
                main.menu_cate.p = p;
                net_read(null, 'h_menu_cate("recv",' + j + ',' + p + ',{text})', l[j].getAttribute('_url').replace('{page}', p), null, null, l[j].getAttribute('_charset'));
                _$('h_menu_cate_html').innerHTML = '正在加载中,请稍候...';
                break;
            case 'recv':
                var j = arguments[1],
                    p = arguments[2];
                if (main.menu_cate.j != j || main.menu_cate.p != p) return;
                var t = arguments[3],
                    p_max = parseInt(l[j].getAttribute('_p_max'));
                var b = c_strjson(t);
                if (b == null) b = [];
                m.push('<table border="0" cellspacing="0" cellpadding="0" class="list">');
                if (b.length > 0) {
                        for (var i = 0; i < b.length; i++) {
                            var b2 = {};
                            try {
                                b2.bkey = "";
                                b2.book = book_FilterText(b[i].novelName || b[i].name);
                                b2.author = book_FilterText(b[i].author);
                                b2.type = b[i].classes;
                                b2.desc = b[i].description || b[i].desc;
                                b2.url = b[i].fromWeb;
                                b2.chapter = b[i].lastChapterName;
                                b2.chapterurl = b[i].fromWeb;
                                b2.chaptermd5 = "";
                                b2.chaptercid = b[i].chapterNum;
                                b2.site = b[i].fromWeb;
                                b2.date = 0;
                                b2.chapterNum = b[i].chapterCount;
                                b2.id = b[i].enid;
                                b2.md = b[i].nid;
                                b2.loc = 1;
                                b2.sourceNum = parseInt(Math.random() * 99);
                                b2.nameMD5 = '';
                                b2.authorMD5 = '';
                                b2.status = (b[i].attribute == '全本' ? '1' : '0');
                                b2.picurl = b[i].imgUrl || b[i].imgurl
                            } catch (e) {
                                continue
                            };
                            if (b2.md == '') continue;
                            var pid = "h_menu_cate_rnd_" + parseInt(Math.random() * 99999);
                            m.push('<tr id="' + pid + '" _bookid="' + (calcMD5(b2.book + '__' + b2.author)) + '" _stype="web" _from="sogou" _local="0" _offset="-1" _json="' + enchar(Json2String(b2)) + '">');
                            m.push('<td class="listimg">');
                            m.push('<a href="#" onfocus=this.blur() onclick="h_OpenBook(\'' + pid + '\');return false"><span></span><img width="82px" height="102px" error="errimg(this)" src="' + b2.picurl + '" /></a>');
                            m.push('</td>');
                            m.push('<td class="infostd">');
                            m.push('<h4><a onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + b2.book + '</a></h4>');
                            m.push('作者：<a onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + b2.author + '</a><br />');
                            m.push('最新章节：<a onfocus=this.blur() href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + b2.chapter + '</a>');
                            m.push('<div>简介：' + left(b2.desc, 140) + '</div>');
                            m.push('</td>');
                            m.push('<td>' + (b2.status == '0' ? '<span class="red">连载中</span>' : '<span>已完结</span>') + '</td>');
                            m.push('<td><a onfocus=this.blur() href="#" class="button" onclick="h_OpenBook(\'' + pid + '\');return false">立即查看</a></td>');
                            m.push('</tr>');
                        };
                    } else {
                        m.push('暂无数据!');
                    };
                m.push('</table>');
                m.push('<div class="page">');
                if (p_max > 1 && p > 1) m.push('<a onfocus=this.blur() href="#" onclick="h_menu_cate(\'get\',' + main.menu_cate.j + ',1)">首页</a><a onfocus=this.blur() href="#" onclick="h_menu_cate(\'get\',' + main.menu_cate.j + ',' + (p - 1) + ')">上一页</a>');
                else m.push('<span>首页</span><span>上一页</span>');
                var x = p - 3,
                    y = p + 3;
                if (x < 0) y += Math.abs(x);
                if (y > p_max) x -= y - p_max,
                y = p_max;
                if (x < 1) x = 1;
                for (var i = x; i <= y; i++) {
                        if (i == p) m.push('<strong>' + i + '</strong>');
                        else m.push('<a href="#" onclick="h_menu_cate(\'get\',' + main.menu_cate.j + ',' + (i) + ')" onfocus=this.blur()>' + i + '</a>');
                    };
                if (p_max > 1 && p < p_max) m.push('<a onfocus=this.blur() href="#" onclick="h_menu_cate(\'get\',' + main.menu_cate.j + ',' + (p + 1) + ')">下一页</a><a onfocus=this.blur() href="#" onclick="h_menu_cate(\'get\',' + main.menu_cate.j + ',' + p_max + ')">尾页</a>');
                else m.push('<span>下一页</span><span>尾页</span>');
                m.push('</div>');
                _$('h_menu_cate_html').innerHTML = m.join('');
                break;
            default:
                var l = 'all,全部,yanqing,言情,xuanhuan,玄幻,dushi,都市,qingxiaoshuo,轻小说,xiaoyuan,校园,mingzhu,名著,lingyi,灵异,wuxia,武侠,lishi,历史,juqing,剧情,wangyou,网游,kehuan,科幻,junshi,军事,zhentan,侦探,jishi,纪实,default,其他'.split(',');
                var l = 'all,全部,%E8%A8%80%E6%83%85,言情,%E7%8E%84%E5%B9%BB,玄幻,%E9%83%BD%E5%B8%82,都市,%E8%BD%BB%E5%B0%8F%E8%AF%B4,轻小说,%E6%A0%A1%E5%9B%AD,校园,%E5%90%8D%E8%91%97,名著,%E7%81%B5%E5%BC%82,灵异,%E6%AD%A6%E4%BE%A0,武侠,%E5%8E%86%E5%8F%B2,历史,%E5%89%A7%E6%83%85,剧情,%E7%BD%91%E6%B8%B8,网游,%E7%A7%91%E5%B9%BB,科幻,%E5%86%9B%E4%BA%8B,军事,%E4%BE%A6%E6%8E%A2,侦探,%E7%BA%AA%E5%AE%9E,纪实,%E5%85%B6%E4%BB%96,其他'.split(',');
                m.push('<div id="topbar" class="listopbar" style="display:none">');
                m.push('<ul class="listmenu" id="h_menu_cate_ul" style="width:auto">');
                var j = 0,
                    m2 = new Array();
                for (var i = 0; i < l.length - 1; i = i + 2) {
                        var url;
                        if (i == 0) url = 'http://book.easou.com/ta/searchMoreBoosAjax.m?page={page}&word=%E5%AE%8C%E7%BB%93';
                        else url = 'http://book.easou.com/ta/searchMoreBoosAjax.m?page={page}&word=' + l[i];
                        m2.push('<li id="h_menus" onclick="h_changeMenu(this)" _i="4' + j + '" _focus="current" _blur=""><a onfocus=this.blur() href="#" onclick="return false"><i></i>' + l[i + 1] + '</a></li>');
                        m.push('<li _name="' + l[i + 1] + '" _url="' + url + '" _p_max="20" _charset="65001"><a onfocus=this.blur() href="#" onclick="h_menu_cate(\'change\',' + (j++) + ');return false">' + l[i + 1] + '</a></li>');
                    };
                m.push('</ul>');
                m.push('</div>');
                m.push('<div id="topbar"><strong id="h_menu_cate_name"></strong><div class="searchbox"><input id="h_search" onkeyup="h_Search_Input(1)" type="text" size="18" value="' + config.defaultkey + '" onfocus="if (value ==\'' + config.defaultkey + '\'){value =\'\'}" onblur="if (value ==\'\'){value=\'' + config.defaultkey + '\'}"><input onclick="h_Search_Input(2)" type="button" class="button" /></div></div>');
                m.push('<div id="h_menu_cate_html"></div>');
                _$('h_menu_4').innerHTML = m.join('');
                main.menu_cate.l = _$('h_menu_cate_ul').getElementsByTagName('li');
                _$('h_menu_4_li').innerHTML = m2.join('');
                break;
            };
    };

function h_menu_top(act) {
        if (main.menu_top == null) main.menu_top = new Object();
        var l = main.menu_top.l,
            m = new Array();
        switch (act) {
            case 'change':
                var j = arguments[1];
                if (j == null) j = 0;
                for (var i = 0; i < l.length; i++) l[i].className = (i == j ? 'current' : '');
                _$('h_menu_top_home').style.display = j == 0 ? '' : 'none';
                _$('h_menu_top_html').style.display = j == 0 ? 'none' : '';
                if (j > 0) h_menu_top('get', j);
                break;
            case 'get':
                var j = arguments[1],
                    p = arguments[2];
                if (p == null) p = 1;
                main.menu_top.j = j;
                main.menu_top.p = p;
                net_read(null, 'h_menu_top("recv",' + j + ',' + p + ',{text})', l[j].getAttribute('_url').replace('{page}', p), null, null, l[j].getAttribute('_charset'));
                _$('h_menu_top_html').innerHTML = '正在加载中,请稍候...';
                break;
            case 'recv':
                var j = arguments[1],
                    p = arguments[2];
                if (main.menu_top.j != j || main.menu_top.p != p) return;
                var t = arguments[3],
                    p_max = parseInt(l[j].getAttribute('_p_max'));
                var b = c_strjson(t);
                if (b == null) b = [];
                m.push('<table border="0" cellspacing="0" cellpadding="0" class="tblist">');
                m.push('<tr>');
                m.push('<th scope="col">排名</th>');
                m.push('<th scope="col">类别</th>');
                m.push('<th scope="col">书名/最新章节</th>');
                m.push('<th scope="col">更新时间</th>');
                m.push('<th scope="col">作者</th>');
                m.push('<th scope="col">操作</th>');
                m.push('</tr>');
                if (b.length > 0) {
                        for (var i = 0; i < b.length; i++) {
                            var j = (((p - 1) * 20) + i + 1);
                            var b2 = {};
                            try {
                                b2.bkey = "";
                                b2.book = book_FilterText(b[i].novelName || b[i].name);
                                b2.author = book_FilterText(b[i].author);
                                b2.type = b[i].classes;
                                b2.desc = b[i].description || b[i].desc;
                                b2.url = b[i].fromWeb;
                                b2.chapter = b[i].lastChapterName;
                                b2.chapterurl = b[i].fromWeb;
                                b2.chaptermd5 = "";
                                b2.chaptercid = b[i].chapterNum;
                                b2.site = b[i].fromWeb;
                                b2.date = 0;
                                b2.chapterNum = b[i].chapterCount;
                                b2.id = b[i].enid;
                                b2.md = b[i].nid;
                                b2.loc = 1;
                                b2.sourceNum = parseInt(Math.random() * 99);
                                b2.nameMD5 = '';
                                b2.authorMD5 = '';
                                b2.status = (b[i].attribute == '全本' ? '1' : '0');
                                b2.picurl = b[i].imgUrl || b[i].imgurl
                            } catch (e) {
                                continue
                            };
                            if (b2.md == '') continue;
                            var pid = "h_menu_cate_rnd_" + parseInt(Math.random() * 99999);
                            m.push('<tr id="' + pid + '" _bookid="' + (calcMD5(b2.book + '__' + b2.author)) + '" _stype="web" _from="sogou" _local="0" _offset="-1" _json="' + enchar(Json2String(b2)) + '">');
                            m.push('<td><span class="flagtop' + (j > 3 ? '' : j) + '">' + j + '</span></td>');
                            m.push('<td><a href="#" onclick="h_changeMenu(4);h_menu_cate(\'change\',\'' + jschar(b2.type) + '\');return false">[' + b2.type + ']</a></td>');
                            m.push('<td><a href="#" class="blue" onclick="h_OpenBook(\'' + pid + '\');return false">' + b2.book + '</a></td>');
                            m.push('<td><span class="green" style="display:none">' + time_func(b2.date) + '</span></td>');
                            m.push('<td><a href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + b2.author + '</a></td>');
                            m.push('<td><a href="#" class="button" onclick="h_OpenBook(\'' + pid + '\');return false">立即阅读</a></td>');
                            m.push('</tr>');
                        };
                    } else {
                        m.push('<tr><td colspan=6>暂无数据!</th></tr>');
                    };
                m.push('</table>');
                m.push('<div class="page">');
                if (p_max > 1 && p > 1) m.push('<a onfocus=this.blur() href="#" onclick="h_menu_top(\'get\',' + main.menu_top.j + ',1)">首页</a><a onfocus=this.blur() href="#" onclick="h_menu_top(\'get\',' + main.menu_top.j + ',' + (p - 1) + ')">上一页</a>');
                else m.push('<span>首页</span><span>上一页</span>');
                var x = p - 3,
                    y = p + 3;
                if (x < 0) y += Math.abs(x);
                if (y > p_max) x -= y - p_max,
                y = p_max;
                if (x < 1) x = 1;
                for (var i = x; i <= y; i++) {
                        if (i == p) m.push('<strong>' + i + '</strong>');
                        else m.push('<a href="#" onclick="h_menu_top(\'get\',' + main.menu_top.j + ',' + (i) + ')" onfocus=this.blur()>' + i + '</a>');
                    };
                if (p_max > 1 && p < p_max) m.push('<a onfocus=this.blur() href="#" onclick="h_menu_top(\'get\',' + main.menu_top.j + ',' + (p + 1) + ')">下一页</a><a onfocus=this.blur() href="#" onclick="h_menu_top(\'get\',' + main.menu_top.j + ',' + p_max + ')">尾页</a>');
                else m.push('<span>下一页</span><span>尾页</span>');
                m.push('</div>');
                _$('h_menu_top_html').innerHTML = m.join('');
                break;
            case 'top':
                var j = arguments[1],
                    t = arguments[2];
                var b = c_strjson(t);
                if (b == null) b = [];
                if (b.length == 0) return;
                for (var i = 0; i < b.length; i++) {
                        var b2 = {};
                        try {
                            b2.bkey = "";
                            b2.book = book_FilterText(b[i].novelName || b[i].name);
                            b2.author = book_FilterText(b[i].author);
                            b2.type = b[i].classes;
                            b2.desc = b[i].description || b[i].desc;
                            b2.url = b[i].fromWeb;
                            b2.chapter = b[i].lastChapterName;
                            b2.chapterurl = b[i].fromWeb;
                            b2.chaptermd5 = "";
                            b2.chaptercid = b[i].chapterNum;
                            b2.site = b[i].fromWeb;
                            b2.date = 0;
                            b2.chapterNum = b[i].chapterCount;
                            b2.id = b[i].enid;
                            b2.md = b[i].nid;
                            b2.loc = 1;
                            b2.sourceNum = parseInt(Math.random() * 99);
                            b2.nameMD5 = '';
                            b2.authorMD5 = '';
                            b2.status = (b[i].attribute == '全本' ? '1' : '0');
                            b2.picurl = b[i].imgUrl || b[i].imgurl
                        } catch (e) {
                            continue
                        };
                        if (b2.md == '') continue;
                        var c = '',
                            n = i + 1,
                            pid = "h_menu_top_home_rnd_" + parseInt(Math.random() * 99999);
                        if (i == 0) c = 'red';
                        if (i > 0 && i < 3) c = 'blue';
                        if (n < 10) n = '0' + n;
                        m.push('<li id="' + pid + '" _bookid="' + (calcMD5(b2.book + '__' + b2.author)) + '" _stype="web" _from="sogou" _local="0" _offset="-1" _json="' + enchar(Json2String(b2)) + '" title="' + hxmlchar(b2.book) + '"><span class="' + c + '">' + n + '.</span><a href="#" onclick="h_changeMenu(4);h_menu_cate(\'change\',\'' + jschar(b2.type) + '\');return false">[' + b2.type + ']</a> <a href="#" onclick="h_OpenBook(\'' + pid + '\');return false">' + left(b2.book, 20) + '</a></li>');
                    };
                _$('h_menu_top_home_' + j).innerHTML = m.join('');
                _$('h_menu_top_home_' + j).style.height = '500px';
                break;
            default:
                main.menu_top = new Object();
                var l = 'all,首页,%E7%94%B7%E7%94%9F,男生排行,%E5%A5%B3%E7%94%9F,女生排行,%E5%AE%8C%E7%BB%93,总排行'.split(','),
                    m2 = new Array(),
                    m3 = new Array();
                var j = 0;
                for (var i = 0; i < l.length - 1; i = i + 2) {
                        var url;
                        if (i == 0) url = '';
                        else url = 'http://book.easou.com/ta/searchMoreBoosAjax.m?page={page}&word=' + l[i];
                        if (j > 0) {
                            m2.push('<div class="toplist toplist' + j + '"><h3><a href="#" onclick="h_menu_top(\'change\',' + (j) + ');return false"><span class="hover">完整榜单</span><i></i><strong>' + l[i + 1] + '</strong></a><span class="more" onclick="h_menu_top(\'change\',' + (j) + ');return false"></span></h3><ul id="h_menu_top_home_' + j + '"></ul></div>');
                            m3.push('net_read(null,\'h_menu_top("top",' + j + ',{text})\',\'' + url.replace('{page}', 1).replace('20', '20') + '\',null,null,\'65001\')');
                        };
                        m.push('<li _url="' + url + '" _p_max="20" _charset="65001"><a onfocus=this.blur() href="#" onclick="h_menu_top(\'change\',' + (j++) + ');return false">' + l[i + 1] + '</a></li>');
                    };
                _$('h_menu_top_menu').innerHTML = m.join('');
                _$('h_menu_top_home').innerHTML = m2.join('');
                main.menu_top.l = _$('h_menu_top_menu').getElementsByTagName('li');
                h_menu_top('change', 0);
                eval(m3.join(';'));
                break;
            };
    };

function h_init() {
        main.body.style.overflow = 'hidden';
        _scroll.func('scroll_home', document.documentElement.clientHeight - 38);
        h_resize();
        h_loaddata('fav');
        main.timer_his = window.setTimeout("h_loaddata('his')", 1000);
        h_changeMenu(1);
        window.ts_focus = function () {
            this.focus();
        };
        window.ts_show = function () {
            window.setTimeout(function () {
                this.focus();
                var r = getCookie('act_his'),
                    r2;
                if (main.act_his != r && r != '' || _$('h_menu_2').style.display != 'none') {
                        if (r != '') main.act_his = r;
                        main.timer_his = window.setTimeout("h_loaddata('his')", 100);
                    };
                var _list = 0;
                r = getCookie('act_fav');
                r2 = getCookie('act_home_refresh');
                if (main.act_fav != r && r != '' || r2 == '1') {
                        _list = 1;
                        main.act_fav = r;
                        setCookie('act_home_refresh', '0', -1);
                        main.timer_fav = window.setTimeout("h_loaddata('fav')", 100);
                    };
                if (_list == 0) h_update('list');
            }, 100);
        };
        window.onresize = function () {
            h_resize()
        };
        window.setTimeout('h_update()', 1000);
        setCookie('act_home_refresh', '0', -1);
        h_menu_top();
        h_menu_cate();
        if (_$('h_shelf').innerHTML == '') h_changeMenu(3);
    }; /*reader*/
var theme = new Array();

function r_rrcd_up() {
        main.rrcd = null
    };

function r_rrcd_move() {
        if (main.rrcd == null || event.button != 1) return;
        var x = event.clientX,
            x2 = main.rrcd.left + x - main.rrcd.x;
        if (x2 < main.rrcd._min || x2 > main.rrcd._max) return;
        main.rrcd.left = x2;
        main.rrcd.o.style.left = main.rrcd.left + 'px';
        main.rrcd.x = x;
        x2 = parseInt(parseInt(main.rrcd.min) + (x2 - main.rrcd._min) / main.rrcd._num * main.rrcd.num);
        r_setReaderStyle('{"' + main.rrcd._type + '":' + x2 + '}', null, 1)
    };

function r_rrcd_down(o) {
        main.rrcd = new Object();
        main.rrcd.o = o;
        main.rrcd._min = o.getAttribute('_min');
        main.rrcd._max = o.getAttribute('_max');
        main.rrcd._num = main.rrcd._max - main.rrcd._min;
        main.rrcd.min = o.getAttribute('min');
        main.rrcd.max = o.getAttribute('max');
        main.rrcd.num = main.rrcd.max - main.rrcd.min;
        main.rrcd._type = o.getAttribute('_type');
        main.rrcd.left = parseInt(o.style.left);
        main.rrcd.x = event.clientX
    };

function r_rrcd_set(id, v) {
        var o = _$('r_rrcd_' + id);
        if (o == null) return;
        var _min = o.getAttribute('_min'),
            _max = o.getAttribute('_max'),
            _num = _max - _min,
            min = o.getAttribute('min'),
            max = o.getAttribute('max'),
            num = max - min;
        o.style.left = parseInt(parseInt(_min) + (v - min) / num * _num) + 'px'
    };

function r_setReaderStyle(v, issave, set) {
        if (issave == null) issave = true;
        var def = '{"theme":1,"mode":0,"fontfamily":"宋体","fontsize":14,"lineheight":"180","pagewidth":800}',
            file = _path + '\\reader_config';
        theme[0] = new Array('6b6b6b', '000000');
        theme[1] = new Array('454545', 'ffffff');
        theme[2] = new Array('333333', 'eeeeee');
        theme[3] = new Array('4b3118', 'fae2bc');
        theme[4] = new Array('23442f', 'ddeedc');
        theme[5] = new Array('354961', 'ccdded');
        theme[6] = new Array('44344f', '44344f');
        var t = _$('r_1_text'),
            tt = _$('r_1_title'),
            tp = t.parentNode,
            j = c_strjson(v);
        for (var k in j) {
                var k2 = j[k];
                switch (k) {
                case 'reset':
                    r_setReaderStyle(def);
                    return;
                    break;
                case 'mode':
                    main.reader_config.mode = k2;
                    var objs = _$$('r_1_mode');
                    for (var i = 0; i < objs.length; i++) objs[i].style.display = k2 == i ? 'none' : '';
                    var ki = k2 == 1 ? 0 : main.reader_config.theme;
                    tp.style.color = '#' + theme[ki][0];
                    main.reader.style.background = '#' + theme[ki][1];
                    if (main.reader.style.display != 'none') {
                        main.body.style.background = '#' + theme[ki][1];
                        r_scrollStyle(k2);
                    } else r_scrollStyle(0);
                    break;
                case 'theme':
                    main.reader_config.theme = k2;
                    var ki = k2;
                    tp.style.color = '#' + theme[ki][0];
                    main.reader.style.background = '#' + theme[ki][1];
                    var objs = _$$('r_1_theme');
                    for (var i = 0; i < objs.length; i++) objs[i].className = ((i + 1) == k2 ? 'select ' : '') + 'bg' + (i + 1);
                    main.body.style.background = '';
                    r_setReaderStyle('{"mode":0}');
                    break;
                case 'fontfamily':
                    var fonts = new Object();
                    fonts['宋体'] = 'SimSun';
                    fonts['楷体'] = 'KaiTi_GB2312';
                    fonts['雅黑'] = 'Microsoft YaHei';
                    main.reader_config.fontfamily = k2;
                    t.style.fontFamily = fonts[k2];
                    tt.style.fontFamily = fonts[k2];
                    var objs = _$$('r_1_fontfamily');
                    for (var i = 0; i < objs.length; i++) objs[i].className = objs[i].innerText == k2 ? 'select' : '';
                    break;
                case 'fontsize':
                    if (k2 <= 1) k2 = main.reader_config.fontsize + k2;
                    main.reader_config.fontsize = k2;
                    t.style.fontSize = k2 + 'px';
                    if (set == null) r_rrcd_set(k, k2);
                    break;
                case 'lineheight':
                    if (k2 <= 1) k2 = main.reader_config.lineheight + k2 * 2;
                    main.reader_config.lineheight = k2;
                    t.style.lineHeight = k2 + '%';
                    if (set == null) r_rrcd_set(k, k2);
                    break;
                case 'pagewidth':
                    if (k2 <= 1) k2 = main.reader_config.pagewidth + k2 * 50;
                    main.reader_config.pagewidth = k2;
                    tp.style.width = k2 + 'px';
                    if (set == null) r_rrcd_set(k, k2);
                    break;
                case 'load':
                    var u = readfile(file);
                    if (u == '') u = def;
                    main.reader_config = c_strjson(u);
                    setCookie('act_reader_config', calcMD5(u));
                    r_setReaderStyle(u, false);
                    break;
                };
            };
        if (issave) {
                var u = Json2String(main.reader_config);
                setCookie('act_reader_config', calcMD5(u));
                writefile(file, u);
            };
    };

function r_changeSite(text) {
        return;
        var j = c_strjson(text);
        if (main.db.md == j.md) return;
        main.db.md = j.md;
        main.db.have = 0;
        main.db.offset = 0;
        main.db.update = -1;
        r_savebook(main.db);
        r_updateButton();
        _$('r_1_sites').setAttribute('_l', null);
        _$('i_1_list_new').innerHTML = '';
        _$('i_1_list').innerHTML = '';
        _$('i_1_loading').style.display = '';
        main.body.scrollTop = 0;
        main.genListMin = null;
        net_read(null, 'r_bookInfo({text},"' + j.cmd + '")', 'http://k.sogou.com/apt/app/menu?md=' + main.db.md + '&eid=0&uid=&sdkandroid=2.3.7&versioncode=1321', null, null, '936');
        if (j.cmd != '') _$('r_1_text').innerHTML = '<div class="text-c" style="margin-left:30px;padding-bottom:300px"><img src="images/loading.GIF" width="80" height="80"></div>';
    };

function r_chapterText(md, act, offset, text) {
    //alert(md + "\n" + act + "\n" + offset + "\n" + offset)
        if (md == null) md = main.db.md;
        var file = main.path + offset;
        switch (act) {
        case 'get':
        case 'cache':
            if (text == null) {
                var _n = '';
                if (act == 'get') {
                    main.r_booklist_a_status = 1;
                    main.db.lasttime = time_func();
                    _$('read-main').scrollTop = 0;
                    main.db.offset = offset;
                    main.db.have = 0;
                    main.db.read = 1;
                    _$('r_1_text').innerHTML = '<div class="text-c" style="margin-left:30px;padding-bottom:900px"><img src="images/loading.GIF" width="80" height="80"></div>';
                    if (main.db.his == 0 || true) c_operHisFav('his', 'add', main.db);
                    r_change('reader');
                    if (main.db.chapter.length > 0) {
                        var r1lp = _$('r_1_listmin_p'),
                            r1l = _$('r_1_listmin');
                        if (r1lp.getAttribute('_omo') == null) {
                                r1lp.setAttribute('_omo', 1);
                                r1lp.onmouseover = function () {
                                    if (this.getAttribute('_load') == null) {
                                        this.setAttribute('_load', 1);
                                        window.setTimeout(function () {
                                            _$('r_1_listmin').scrollTop = main.db.offset * 29;
                                            main.genListMin_pre = main.db.offset;
                                            main.genListMin_list[main.genListMin_pre].style.color = '#3BB0E8'
                                        }, 100)
                                    }
                                };
                            };
                        r1l.scrollTop = main.db.offset * 29;
                        try {
                                if (main.genListMin_pre != null) main.genListMin_list[main.genListMin_pre].style.color = '';
                                main.genListMin_pre = main.db.offset;
                                main.genListMin_list[main.genListMin_pre].style.color = '#3BB0E8';
                            } catch (e) {};
                    }; /*r_savebook(main.db);*/
                    _$('r_1_same').innerHTML = '<select onchange="if(this.value!=\'\')r_changeSite(this.value)" id="r_1_sameo" onclick="if(this.getAttribute(\'_l\')==null) {this.setAttribute(\'_l\',1);r_chapterText(\'' + md + '\',\'same\',\'' + main.db.chapter[offset].cmd + '\')}"><option value="">相似章节</option></select>';
                    if (main.genListMin == null) r_genListMin();
                };
                if (main.db.his != 0 || main.db.fav != 0) _n = readfile(file);
                try {
                    var _n2 = c_strjson(_n);
                    if (_n2.md != md) _n = ''
                } catch (e) {
                    _n = ''
                };
                if (_n != '') {
                    r_chapterText(md, act, offset, c_strjson(_n));
                    return;
                } else {
                    net_read(null, 'r_chapterText("' + md + '","' + act + '",' + offset + ',{text})', 'http://book.easou.com/ta/showAjax.m?esid=GpdHG7mv4MaApktmv8&gid=' + main.db.ext.id + '&nid=' + md + '&st=' + (offset + 1) + '&ap=1&cu=http&gst=' + (offset + 1), null, null, '65001');
                };
            } else {
                var _cmd, _title, _url, _offset, _text;
                if (act == 'get' && main.db.offset == offset) {
                    _$('r_1_prev').className = (main.db.chapter.length > 1 && offset > 0) ? 'btnpre' : '';
                    _$('r_1_next').className = (main.db.chapter.length > 1 && offset <= main.db.chapter.length - 2) ? 'btnnext' : '';
                };
                if (typeof(text) == 'string') {
                    text = book_FilterJson(text);
                    var json;
                    try {
                        json = c_strjson(text)
                    } catch (e) {};
                    if (json == null && act == 'get') {
                        _$('r_1_text').innerHTML = '<div style="padding-bottom:60%"><center><h3>数据获取错误!</h3></center></div>';
                        return;
                    };
                    _cmd = 'gid=' + main.db.ext.id + '&nid=' + md + '&st=' + (offset + 1) + '&gst=' + (offset + 1) + '&t=' + enchar(json.chapterName);
                    _title = json.chapterName || '';
                    _url = json.cu || '';
                    _offset = offset;
                    _text = book_FilterText(json.content == null ? '内容获取失败!' : json.content);
                    var chapter = '{"md":"' + jschar(md) + '","cmd":"' + jschar(_cmd) + '","title":"' + jschar(_title) + '","url":"' + jschar(_url) + '","offset":"' + _offset + '","text":"' + jschar(_text) + '"}';
                    if (main.db.his != 0 || main.db.fav != 0) writefile(file, chapter);
                } else {
                    var json = text;
                    _cmd = json.cmd;
                    _title = json.title;
                    _url = json.url;
                    _offset = offset;
                    _text = json.text;
                };
                if (act == 'get' && main.db.offset == offset) {
                    var _textobj = _$('r_1_text');
                    _$('r_1_url').value = _url;
                    _$('r_1_title').innerHTML = _title;
                    _textobj.innerHTML = book_FormatText(_text);
                    if ((main.db.his != 0 || main.db.fav != 0) && main.db.offset < main.db.chapter.length) r_chapterText(md, 'cache', main.db.offset + 1);
                    _$('r_1_sameo').setAttribute('_l', 1);
                    r_chapterText(md, 'same', _cmd);
                };
            };
            break;
        case 'same':
            return;
            if (text == null) {
                net_read(null, 'r_chapterText("' + md + '","' + act + '",' + offset + ',{text})', 'http://k.sogou.com/novel/ajax/similarChapter?uID=&sgid=0&gf=e-d-pnd-i&md=' + md + '&v=5&cmd=' + offset, null, null, '65001');
            } else {
                var o = _$('r_1_sameo'),
                    u = [],
                    u2 = new Array();
                try {
                        u = c_strjson(text)
                    } catch (e) {};
                for (var i = 0; i < u.length; i++) {
                        o.options[i + 1] = new Option(u[i].chapterNameExt + ' (' + u[i].sourceExt + ')', '{"s":"chapter","md":"' + u[i].md + '","cmd":"' + u[i].cmdExt + '"}');
                    };
            };
        };
    };

function r_resize(w, h) {
        if (w == null) w = document.documentElement.clientWidth,
        h = document.documentElement.clientHeight;
        if (main.resize_w == w || main.resize_h == h) return;
        main.resize_w = w;
        main.resize_h = h;
        var m = _$('read-main');
        m.style.width = (w - 80) + 'px';
        m.style.height = (h - 80) + 'px';
    };

function r_gopage(s) {
        var c = main.db.offset;
        if (c < 0) c = 0;
        if (c >= main.db.chapter.length) c = main.db.chapter.length - 1;
        switch (s) {
        case -1:
            c += -1;
            break;
        case -2:
            c += 1;
            break;
        default:
            c = s;
            break;
        };
        if (c < 0 || c >= main.db.chapter.length) return;
        _$('r_1_title').innerHTML = main.db.chapter[c].chapterName;
        r_chapterText(null, 'get', c);
    };

function r_change(v) {
        switch (v) {
        case 'reader':
            if (main.reader.style.display == 'none') {
                main.reader.style.display = '',
                main.info.style.display = 'none',
                r_scrollStyle(main.reader_config.mode);
                main.body.style.background = '#' + theme[main.reader_config.mode == 0 ? main.reader_config.theme : 0][1];
                main.body.style.overflowX = 'hidden';
                main.body.style.overflowY = 'hidden';
            };
            break;
        case 'info':
            if (main.info.style.display == 'none') {
                main.reader.style.display = 'none',
                main.info.style.display = '',
                r_scrollStyle(0);
                main.body.style.overflowX = 'hidden';
                main.body.style.overflowY = 'auto';
                if (main.r_booklist_a_status != null) window.setTimeout(function () {
                    main.r_booklist_a_status = null;
                    var as = _$$('r_booklist_a');
                    for (var i = 0; i < as.length; i++) {
                        var _offset = parseInt(as[i].getAttribute('_offset'));
                        as[i].style.color = main.db.offset >= _offset ? '#c6c6c6' : '';
                    };
                }, 100);
            }
            document.body.style.background = '';
            break;
        }
        r_resize();
    };

function r_savebook(db) {
        var path = _path + '\\' + db.bookid + '\\';
        if (db.picurl.substr(0, 4) == 'http') {
            var pic = path + 'logo.jpg';
            net_read(null, null, db.picurl, null, null, null, pic);
            db.picurl = pic;
        };
        var jg = Json2String(db);
        writefile(path + 'main', jg);
    };

function r_bookInfo(text, cmd, iswrite, isdown) {
        main.genListMin = null;
        var json = c_strjson(text);
        if (cmd == null) cmd = '';
        var chapter = json.chapter;
        if (isdown) if (Json2String(main.db.chapter) == Json2String(chapter)) return;
        main.db.chapter = chapter;
        if (main.db.update < 0) main.db.update = chapter.length - 1;
        if ((main.db.his == 1 || main.db.fav == 1) && iswrite == null) {
            main.db.have = 0;
            r_savebook(main.db);
        };
        var u = new Array(),
            i = 1;
        for (var j = chapter.length - 1; j >= 0; j--) {
                u.push('<li><a id="r_booklist_a" _offset=' + j + ' href="#" class="blue" ' + (main.db.offset >= j ? 'style="color:#c6c6c6"' : '') + ' onfocus=this.blur() onclick="r_chapterText(null,\'get\',' + j + ');return false">' + chapter[j].chapterName + '</a></li>');
                if (++i > 3) break;
            };
        _$('i_1_list_new').innerHTML = u.join('');
        window.clearTimeout(main.timer_sortChapter);
        main.timer_sortChapter = window.setTimeout(function () {
                var j = r_sortChapter(main.sort, cmd);
                _$('i_1_loading').style.display = 'none';
                if (cmd != '' && j != null) {
                    r_chapterText(main.db.md, 'get', j);
                };
            }, 100);
    };

function r_fullscreen() {
        api_FullScreen(main.fullscreen ? '0' : '1');
        main.fullscreen = !main.fullscreen;
        window.setTimeout(function () {
            this.focus()
        }, 500);
    };

function r_genListMin() {
        main.genListMin = 1;
        var chapter = main.db.chapter;
        var u = new Array();
        for (var j = 0; j < chapter.length; j++) {
            u.push('<li><a href="#" onfocus=this.blur() onclick="r_chapterText(null,\'get\',' + j + ');return false">' + left(chapter[j].chapterName, 30) + '</a></li>');
        };
        _$('r_1_listmin').innerHTML = u.join('');
        main.genListMin_list = _$('r_1_listmin').getElementsByTagName('a');
        main.genListMin_pre = null;
    };

function r_sortChapter(s, cmd) {
    //alert("r_sortChapter");
        if (s == null) s = 'asc';
        main.sort = s;
        var chapter = main.db.chapter,
            jg;
        var u = new Array(),
            u2 = new Array(0, chapter.length);
        if (s == 'desc') u2 = new Array(-(chapter.length - 1), -1);
        var m = 0;
        for (var i = u2[0]; i < u2[1]; i++) {
                m++;
                j = Math.abs(i);
                if (cmd == chapter[j].cmd) jg = j;
                u.push('<li><a id="r_booklist_a" _offset=' + j + ' style="' + (main.db.offset >= j ? 'color:#c6c6c6;' : '') + '" href="#" onfocus=this.blur() onclick="r_chapterText(null,\'get\',' + j + ');return false">' + chapter[j].chapterName + '</a></li>');
                if (main.showall == null) if (m >= 18) break;
            };
        _$('i_1_list').innerHTML = u.join('');
        _$('i_1_sort_zx').className = 'zx' + (s == 'asc' ? 'on' : '');
        _$('i_1_sort_dx').className = 'dx' + (s == 'desc' ? 'on' : '');
        return jg;
    };

function r_scrollStyle(m) {
        var st = new Array(new Array('scrollbarFaceColor', '#383E4C'), new Array('scrollbarTrackColor', '#383E4C'), new Array('scrollbarArrowColor', '#C6C6C6'), new Array('scrollbarDarkShadowColor', '#505561'), new Array('scrollbarShadowColor', '#505561'), new Array('scrollbarBaseColor', '#383E4C'), new Array('scrollbarHighlightColor', '#505561'), new Array('scrollbar3dLightColor', '#383E4C'));
        for (var i = 0; i < st.length; i++) eval('document.body.style.' + st[i][0] + '="' + (m == 0 ? '' : st[i][1]) + '"');
    };

function r_updateButton() {
        var b = _$('i_1_button'),
            mb = new Array();
        if (main.db.read == 1) mb.push('<a href="#" onfocus=this.blur() onclick="r_chapterText(null,\'get\',main.db.offset);return false" class="goread"><i class="ico1"></i>继续阅读</a> ');
        else mb.push('<a href="#" onfocus=this.blur() onclick="r_chapterText(null,\'get\',0);return false" class="read"><i class="ico1"></i>立即阅读</a> ');
        if (main.db.fav == 1) mb.push('<span id="i_1_button_shelf"><i class="ico2"></i>已加书架</span> ');
        else mb.push('<a href="#" onfocus=this.blur() id="r_addShelf" onclick="c_operHisFav(\'fav\',\'add\',main.db);return false" id="i_1_button_shelf"><i class="ico2"></i>加入书架</a> ');
        var lnk = (main.db.book + '.ttx').replace(/[\\/:*?"<>|]/gi, '');
        if (api_DesktopTtx(lnk, 'get') == '1' && readfile(_path + '\\lnk\\' + enchar(lnk) + '.db') != '') mb.push('<span><i class="ico3"></i>已加桌面</span> ');
        else {
                var lnkinfo = '[info]\r\nbook=' + main.db.book + '\r\nauthor=' + main.db.author + '\r\nurl=' + ('http://www.baidu.com/s?word=' + enchar(main.db.book + ' ' + main.db.author) + '&tn=&ie=utf-8') + '\r\nFORM_DESK=' + enchar(lnk);
                var lnk_cs = enchar('{"bookid":"' + main.db.bookid + '","stype":"' + main.db.stype + '","from":"' + main.db.from + '","json":"' + enchar(Json2String(main.db.ext)) + '"}');
                mb.push('<a href="#" lnk_cs="' + lnk_cs + '" onfocus=this.blur() onclick="if(api_DesktopTtx(\'' + lnk + '\',\'set\',\'' + jschar(lnkinfo) + '\')) {var u=this.getAttribute(\'lnk_cs\');writefile(\'' + _path + '\\\\lnk\\\\' + enchar(lnk) + '.db\',dechar(u));r_updateButton();if(main.db.fav==0)_$(\'r_addShelf\').click()};return false"><i class="ico3"></i>加入桌面</a> ');
            };
        b.innerHTML = mb.join('');
    };

function c_mouse(n, s) {
        var rhs = _$(n);
        if (rhs == null) return;
        window.clearTimeout(main['mouse_timer_' + n]);
        if (s == 'over') {
            rhs.style.display = '';
        } else {
            main['mouse_timer_' + n] = window.setTimeout(function () {
                rhs.style.display = 'none'
            }, 300);
        };
    };

function r_bookSite_mouse(s) {
        c_mouse('r_html_site', s)
    };

function r_bookSite(text) {
        return;
        var mb = new Array(),
            rhs = _$('r_html_site');
        if (text == null) {
                net_read(null, 'r_bookSite({text})', 'http://k.sogou.com/api/app/search?json=1&nameMD5=' + main.db.ext.nameMD5 + '&authorMD5=' + main.db.ext.authorMD5 + '&eid=0&nolog=1&uid=&sdkandroid=2.3.7&versioncode=1321&p=1&keyword=' + enchar(main.db.book), null, null, '65001');
                return;
            };
        mb.push('<span class="topline"></span><ul class="orglist">');
        var list;
        try {
                var j = c_strjson(text);
                list = j.list;
                if (list == null) list = [];
            } catch (e) {};
        if (list.length == 0) {
                mb.push('<li>暂无更多来源!</li>');
            } else {
                var j = 0;
                for (var i = 0; i < list.length; i++) {
                    if (list[i].md == main.db.md || list[i].md == '' || list[i].chapter == '') continue;
                    mb.push('<li title="' + hxmlchar(list[i].book + ' 作者:' + list[i].author) + '" onclick="r_bookSite_mouse(\'out\');r_changeSite(\'' + hxmlchar('{"s":"book","md":"' + list[i].md + '","cmd":""}') + '\')" onmouseover="r_bookSite_mouse(\'over\')" onmouseout="r_bookSite_mouse(\'out\')">最新：<a href="#" onfocus=this.blur() onclick="return false">' + left(list[i].chapter, 30) + '</a><br /><span class="green">' + (list[i].loc == '1' ? '最佳来源' : '') + ' ' + list[i].date + '</span></li>');
                    if (++j > 4) break;
                };
            }
        mb.push('</ul><span class="btmline"></span>');
        rhs.innerHTML = mb.join('');
    };

function alllist_load(gid, nid, page, text) { /*	if(text==null){		if(page==1){			window.alllist_load_arr=new Array();		};		net_read(null,'alllist_load('+gid+','+nid+','+(page+1)+',{text})','http://book.easou.com/w/chapter/'+gid+'/'+nid+'/'+page+'_0.html',null,null,'65001');	}else{		if(text.indexOf('下一页')>0){			var re=/<li><span><a[^>]+>([0-9]+)\.(.+?)<\/a><\/span><\/li>/gi;			var arr,arri=0;			while((arr=re.exec(text))!=null){				arri++;				window.alllist_load_arr.push('{"status": 0,"sort": '+arr[1]+',"nid": '+nid+',"chapterName": "'+jschar(arr[2])+'","chapterUrl": "http://wap.cmread.com","gsort": '+arr[1]+',"chapterType": "","lastChapterName": null}');			};			if(text.indexOf('<span class="next">下一页</span>')>0){				alllist_load(gid,nid,page);				return;			};		};		text='{"chapter":['+window.alllist_load_arr.join(',')+']}';		r_bookInfo(text,null,null,1);	}*/
        if (text == null) {
            if (page == 1) {
                window.alllist_load_arr = new Array();
            };
            net_read(null, 'alllist_load("' + gid + '","' + nid + '",' + (page + 1) + ',{text})', 'http://book.easou.com/ta/listAjax.m?esid=Gm25wtmv4OaApktmv8&gid=' + gid + '&nid=' + nid + '&order=0&page=' + page + '&size=25&lastSt=', null, null, '65001');
        } else {
            if (text.indexOf('chapters') > 0) {
                var obj = c_strjson(text).chapters;
                for (var i = 0; i < obj.length; i++) window.alllist_load_arr.push(Json2String(obj[i]));
                alllist_load(gid, nid, page);
            } else {
                text = '{"chapter":[' + window.alllist_load_arr.join(',') + ']}';
                r_bookInfo(text, null, null, 1);
            };
        }
    };

function r_init_2(t) {
        var r = /nid=([0-9]+)&/gi;
        if (r.test(t)) {
            var arr = r.exec(t);
            window.tmp_md = RegExp.$1;
        };
        r_init(1);
    };

function r_init(s) {
        main.showall = 1;
        main.act_reader_config = calcMD5(readfile(_path + '\\reader_config'));
        main.info = _$('main_1_info');
        main.reader = _$('main_1_reader');
        main.fullscreen = false;
        main.db = c_strjson('{}');
        main.bookid = getSearch('bookid');
        main.local = getSearch('local');
        main.path = _path + '\\' + main.bookid + '\\';
        main.offset = parseInt(getSearch('offset'));
        r_setReaderStyle('{"load":"1"}');
        var nr = readfile(main.path + 'main');
        if (nr != '') main.local = '1';
        switch (main.local) {
        case '0':
            var file = getSearch('file');
            try {
                var ext = c_strjson(getCookie(file));
                setCookie(file, '', -1);
                if (window.tmp_ext != null) ext = window.tmp_ext;
                else window.tmp_ext = ext;
            } catch (e) {
                c_tips('show', 'api_CloseTab(\'' + main.bookid + '\')', '参数出错001!', 1);
                return
            };
            main.db.bookid = main.bookid;
            main.db.from = getSearch('from');
            switch (main.db.from) {
            case 'sogou':
                main.db.book = ext.book;
                main.db.author = ext.author;
                main.db.status = ext.status == '0' ? '0' : '1';
                main.db.type = ext.type;
                main.db.picurl = ext.picurl;
                main.db.desc = ext.desc;
                main.db.stype = getSearch('stype');
                main.db.url = ext.url;
                main.db.his = 0;
                main.db.fav = 0;
                main.db.have = 0;
                main.db.offset = main.offset;
                main.db.update = -1;
                main.db.updatetime = time_func();
                if (window.tmp_md != null) ext.md = window.tmp_md;
                main.db.md = ext.md;
                main.db.ext = ext;
                main.db.chapter = [];
                break;
            };
            break;
        case '1':
            try {
                main.db = c_strjson(nr);
            } catch (e) {
                c_tips('show', 'api_CloseTab(\'' + main.bookid + '\')', '读取本地配置文件出错!', 1);
                return;
            };
            main.db.have = 0;
            r_savebook(main.db);
            if (typeof(main.db.chapter) != 'undefined') r_bookInfo('{"chapter":' + Json2String(main.db.chapter) + '}', null, 1);
            break;
        };
        if (main.db.book == null) {
            c_tips('show', 'api_CloseTab(\'' + main.bookid + '\')', '参数出错002!', 1);
            return
        };
        if (s == null) {
            document.title = '(加载中)' + main.db.book; /*net_read(null,'r_init_2({text})','http://book.easou.com/ta/novel.m?esid=7tkQhumv4emdC_umvd&gid='+main.db.ext.id+'&nid='+main.db.ext.md,null,null,'65001');*/
            r_init(1);
            return;
        }
        r_updateButton();
        document.title = main.db.book;
        _$('i_1_title').innerHTML = main.db.book;
        _$('i_1_info').innerHTML = '<li id="i_1_author">作者：' + main.db.author + '</li><li id="i_1_type">分类：' + main.db.type + '</li><li id="i_1_state">状态：' + (main.db.status == '0' ? '连载中' : '已完结') + '</li><li title="' + main.db.url + '">来源：<a id="r_1_sites" href="#" onfocus=this.blur() onclick="return false" onmouseover="if(this.getAttribute(\'_l\')==null) {this.setAttribute(\'_l\',1);r_bookSite()};r_bookSite_mouse(\'over\')" onmouseout="r_bookSite_mouse(\'out\')" class="blue">更多来源站</a><div class="orgbox" onmouseover="r_bookSite_mouse(\'over\')" onmouseout="r_bookSite_mouse(\'out\')" id="r_html_site" style="display:none"></div></li>';
        _$('i_1_desc').innerHTML = main.db.desc;
        _$('i_1_pic').src = main.db.picurl;
        if (main.db.status == '0' || main.local == '0') alllist_load(main.db.ext.id, main.db.ext.md, 1);
        main.info.style.display = '';
        r_change('info');
        window.onresize = function () {
            r_resize()
        };
        document.onkeydown = function () {
            var e = window.event,
                s = e.srcElement,
                k = e.keyCode;
            if (k == 27) if (main.fullscreen) r_fullscreen();
            if (k == 122) r_fullscreen();
            if (main.reader.style.display != 'none') {
                    switch (k) {
                    case 13:
                        if (s.id == 'r_1_url') api_OpenIe(s.value);
                        else _$('r_1_list').click();
                        break;
                    case 37:
                        _$('r_1_prev').click();
                        break;
                    case 39:
                        _$('r_1_next').click();
                        break;
                    };
                    if (k == 37 || k == 39 || k == 13 || k == 27) {
                        e.keyCode = 0;
                        return false
                    };
                    try {
                        _$('read-main').focus()
                    } catch (e) {};
                };
            return main.keydown();
        };
        window.ts_focus = function () {
            this.focus();
        };
        window.ts_show = function () {
            this.focus();
            var r = getCookie('act_reader_config');
            if (r != main.act_reader_config && r != '') main.act_reader_config = r,
            r_setReaderStyle('{"load":"1"}');
        };
        setCookie('act_' + main.bookid, '', -1);
        window.setInterval(function () {
            var r = getCookie('act_his'),
                isr = false;
            if (main.act_his != r && r != '') {
                    main.act_his = r;
                    var r2 = readfile(config.his).indexOf('"' + main.bookid + '"') >= 0 ? 1 : 0;
                    if (main.db.his != r2) isr = true,
                    main.db.his = r2;
                };
            r = getCookie('act_fav');
            if (main.act_fav != r && r != '') {
                    main.act_fav = r;
                    var r2 = readfile(config.fav).indexOf('"' + main.bookid + '"') >= 0 ? 1 : 0;
                    if (main.db.fav != r2) isr = true,
                    main.db.fav = r2;
                };
            var r = getCookie('act_' + main.bookid);
            if (r != '') {
                    setCookie('act_' + main.bookid, '', -1);
                    var r2 = c_strjson(r);
                    switch (r2.act) {
                    case 'have':
                        var b = c_filejson(_path + '\\' + main.db.bookid + '\\main');
                        if (b == null) break;
                        main.db.have = b.have;
                        main.db.chapter = b.chapter;
                        main.genListMin = null;
                        r_bookInfo('{"chapter":' + Json2String(main.db.chapter) + '}', null, 1);
                        break;
                    case 'offset':
                        if (r2.offset >= 0) r_chapterText(null, 'get', r2.offset);
                        break;
                    };
                };
            if (isr) r_updateButton();
        }, 1000);
        if (main.offset >= 0) r_chapterText(null, 'get', main.offset);
    }; /*init*/


function ts_openbook(cs) {
        window.setTimeout(function () {
            if (main.pType != '0') return;
            var b = c_filejson(_path + '\\lnk\\' + cs + '.db');
            if (b == null) {
                var c = dechar(cs);
                c = c.substr(0, c.length - 4);
                h_Search('get', c);
                return
            };
            var d = document;
            var c = d.createElement('a');
            c.href = '#';
            c.setAttribute('_bookid', b.bookid);
            c.setAttribute('_stype', b.stype);
            c.setAttribute('_from', b.from);
            c.setAttribute('_local', '0');
            c.setAttribute('_offset', '-1');
            c.setAttribute('_json', b.json);
            c.onclick = function () {
                h_OpenBook(this, -1);
                return false
            };
            d.body.appendChild(c);
            c.click();
        }, 100);
    };

function init(s) {
        if (s == null) {
            window.setTimeout('init(1)', 10);
            return
        };
        c_syncdata();
        this.focus();
        api_Init();
        main.keydown = document.onkeydown;
        main.body = document.body;
        window.api_ContextMenu = function () {
            return true
        };
        _$('main_' + main.pType).style.display = '';
        switch (main.pType) {
        case '0':
            h_init();
            break;
        case '1':
            r_init();
            break;
        };
    };
if (config.isIE6) {
        var DD_belatedPNG = {
            ns: "DD_belatedPNG",
            imgSize: {},
            delay: 10,
            nodesFixed: 0,
            createVmlNameSpace: function () {
                if (document.namespaces && !document.namespaces[this.ns]) {
                    document.namespaces.add(this.ns, "urn:schemas-microsoft-com:vml")
                }
            },
            createVmlStyleSheet: function () {
                var b, a;
                b = document.createElement("style");
                b.setAttribute("media", "screen");
                document.documentElement.firstChild.insertBefore(b, document.documentElement.firstChild.firstChild);
                if (b.styleSheet) {
                    b = b.styleSheet;
                    b.addRule(this.ns + "\\:*", "{behavior:url(#default#VML)}");
                    b.addRule(this.ns + "\\:shape", "position:absolute;");
                    b.addRule("img." + this.ns + "_sizeFinder", "behavior:none; border:none; position:absolute; z-index:-1; top:-10000px; visibility:hidden;");
                    this.screenStyleSheet = b;
                    a = document.createElement("style");
                    a.setAttribute("media", "print");
                    document.documentElement.firstChild.insertBefore(a, document.documentElement.firstChild.firstChild);
                    a = a.styleSheet;
                    a.addRule(this.ns + "\\:*", "{display: none !important;}");
                    a.addRule("img." + this.ns + "_sizeFinder", "{display: none !important;}")
                }
            },
            readPropertyChange: function () {
                var b, c, a;
                b = event.srcElement;
                if (!b.vmlInitiated) {
                    return
                }
                if (event.propertyName.search("background") != -1 || event.propertyName.search("border") != -1) {
                    DD_belatedPNG.applyVML(b)
                }
                if (event.propertyName == "style.display") {
                    c = (b.currentStyle.display == "none") ? "none" : "block";
                    for (a in b.vml) {
                        if (b.vml.hasOwnProperty(a)) {
                            b.vml[a].shape.style.display = c
                        }
                    }
                }
                if (event.propertyName.search("filter") != -1) {
                    DD_belatedPNG.vmlOpacity(b)
                }
            },
            vmlOpacity: function (b) {
                if (b.currentStyle.filter.search("lpha") != -1) {
                    var a = b.currentStyle.filter;
                    a = parseInt(a.substring(a.lastIndexOf("=") + 1, a.lastIndexOf(")")), 10) / 100;
                    b.vml.color.shape.style.filter = b.currentStyle.filter;
                    b.vml.image.fill.opacity = a
                }
            },
            handlePseudoHover: function (a) {
                setTimeout(function () {
                    DD_belatedPNG.applyVML(a)
                }, 1)
            },
            fix: function (a) {
                if (this.screenStyleSheet) {
                    var c, b;
                    c = a.split(",");
                    for (b = 0; b < c.length; b++) {
                        this.screenStyleSheet.addRule(c[b], "behavior:expression(DD_belatedPNG.fixPng(this))")
                    }
                }
            },
            applyVML: function (a) {
                a.runtimeStyle.cssText = "";
                this.vmlFill(a);
                this.vmlOffsets(a);
                this.vmlOpacity(a);
                if (a.isImg) {
                    this.copyImageBorders(a)
                }
            },
            attachHandlers: function (i) {
                var d, c, g, e, b, f;
                d = this;
                c = {
                    resize: "vmlOffsets",
                    move: "vmlOffsets"
                };
                if (i.nodeName == "A") {
                    e = {
                        mouseleave: "handlePseudoHover",
                        mouseenter: "handlePseudoHover",
                        focus: "handlePseudoHover",
                        blur: "handlePseudoHover"
                    };
                    for (b in e) {
                        if (e.hasOwnProperty(b)) {
                            c[b] = e[b]
                        }
                    }
                }
                for (f in c) {
                    if (c.hasOwnProperty(f)) {
                        g = function () {
                            d[c[f]](i)
                        };
                        i.attachEvent("on" + f, g)
                    }
                }
                i.attachEvent("onpropertychange", this.readPropertyChange)
            },
            giveLayout: function (a) {
                a.style.zoom = 1;
                if (a.currentStyle.position == "static") {
                    a.style.position = "relative"
                }
            },
            copyImageBorders: function (b) {
                var c, a;
                c = {
                    borderStyle: true,
                    borderWidth: true,
                    borderColor: true
                };
                for (a in c) {
                    if (c.hasOwnProperty(a)) {
                        b.vml.color.shape.style[a] = b.currentStyle[a]
                    }
                }
            },
            vmlFill: function (e) {
                if (!e.currentStyle) {
                    return
                } else {
                    var d, f, g, b, a, c;
                    d = e.currentStyle
                }
                for (b in e.vml) {
                    if (e.vml.hasOwnProperty(b)) {
                        e.vml[b].shape.style.zIndex = d.zIndex
                    }
                }
                e.runtimeStyle.backgroundColor = "";
                e.runtimeStyle.backgroundImage = "";
                f = true;
                if (d.backgroundImage != "none" || e.isImg) {
                    if (!e.isImg) {
                        e.vmlBg = d.backgroundImage;
                        e.vmlBg = e.vmlBg.substr(5, e.vmlBg.lastIndexOf('")') - 5)
                    } else {
                        e.vmlBg = e.src
                    }
                    g = this;
                    if (!g.imgSize[e.vmlBg]) {
                        a = document.createElement("img");
                        g.imgSize[e.vmlBg] = a;
                        a.className = g.ns + "_sizeFinder";
                        a.runtimeStyle.cssText = "behavior:none; position:absolute; left:-10000px; top:-10000px; border:none; margin:0; padding:0;";
                        c = function () {
                            this.width = this.offsetWidth;
                            this.height = this.offsetHeight;
                            g.vmlOffsets(e)
                        };
                        a.attachEvent("onload", c);
                        a.src = e.vmlBg;
                        a.removeAttribute("width");
                        a.removeAttribute("height");
                        document.body.insertBefore(a, document.body.firstChild)
                    }
                    e.vml.image.fill.src = e.vmlBg;
                    f = false
                }
                e.vml.image.fill.on = !f;
                e.vml.image.fill.color = "none";
                e.vml.color.shape.style.backgroundColor = d.backgroundColor;
                e.runtimeStyle.backgroundImage = "none";
                e.runtimeStyle.backgroundColor = "transparent"
            },
            vmlOffsets: function (d) {
                var h, n, a, e, g, m, f, l, j, i, k;
                h = d.currentStyle;
                n = {
                    W: d.clientWidth + 1,
                    H: d.clientHeight + 1,
                    w: this.imgSize[d.vmlBg].width,
                    h: this.imgSize[d.vmlBg].height,
                    L: d.offsetLeft,
                    T: d.offsetTop,
                    bLW: d.clientLeft,
                    bTW: d.clientTop
                };
                a = (n.L + n.bLW == 1) ? 1 : 0;
                e = function (b, p, q, c, s, u) {
                    b.coordsize = c + "," + s;
                    b.coordorigin = u + "," + u;
                    b.path = "m0,0l" + c + ",0l" + c + "," + s + "l0," + s + " xe";
                    b.style.width = c + "px";
                    b.style.height = s + "px";
                    b.style.left = p + "px";
                    b.style.top = q + "px"
                };
                e(d.vml.color.shape, (n.L + (d.isImg ? 0 : n.bLW)), (n.T + (d.isImg ? 0 : n.bTW)), (n.W - 1), (n.H - 1), 0);
                e(d.vml.image.shape, (n.L + n.bLW), (n.T + n.bTW), (n.W), (n.H), 1);
                g = {
                    X: 0,
                    Y: 0
                };
                if (d.isImg) {
                    g.X = parseInt(h.paddingLeft, 10) + 1;
                    g.Y = parseInt(h.paddingTop, 10) + 1
                } else {
                    for (j in g) {
                        if (g.hasOwnProperty(j)) {
                            this.figurePercentage(g, n, j, h["backgroundPosition" + j])
                        }
                    }
                }
                d.vml.image.fill.position = (g.X / n.W) + "," + (g.Y / n.H);
                m = h.backgroundRepeat;
                f = {
                    T: 1,
                    R: n.W + a,
                    B: n.H,
                    L: 1 + a
                };
                l = {
                    X: {
                        b1: "L",
                        b2: "R",
                        d: "W"
                    },
                    Y: {
                        b1: "T",
                        b2: "B",
                        d: "H"
                    }
                };
                if (m != "repeat" || d.isImg) {
                    i = {
                        T: (g.Y),
                        R: (g.X + n.w),
                        B: (g.Y + n.h),
                        L: (g.X)
                    };
                    if (m.search("repeat-") != -1) {
                        k = m.split("repeat-")[1].toUpperCase();
                        i[l[k].b1] = 1;
                        i[l[k].b2] = n[l[k].d]
                    }
                    if (i.B > n.H) {
                        i.B = n.H
                    }
                    d.vml.image.shape.style.clip = "rect(" + i.T + "px " + (i.R + a) + "px " + i.B + "px " + (i.L + a) + "px)"
                } else {
                    d.vml.image.shape.style.clip = "rect(" + f.T + "px " + f.R + "px " + f.B + "px " + f.L + "px)"
                }
            },
            figurePercentage: function (d, c, f, a) {
                var b, e;
                e = true;
                b = (f == "X");
                switch (a) {
                case "left":
                case "top":
                    d[f] = 0;
                    break;
                case "center":
                    d[f] = 0.5;
                    break;
                case "right":
                case "bottom":
                    d[f] = 1;
                    break;
                default:
                    if (a.search("%") != -1) {
                        d[f] = parseInt(a, 10) / 100
                    } else {
                        e = false
                    }
                }
                d[f] = Math.ceil(e ? ((c[b ? "W" : "H"] * d[f]) - (c[b ? "w" : "h"] * d[f])) : parseInt(a, 10));
                if (d[f] % 2 === 0) {
                    d[f]++
                }
                return d[f]
            },
            fixPng: function (c) {
                c.style.behavior = "none";
                var g, b, f, a, d;
                if (c.nodeName == "BODY" || c.nodeName == "TD" || c.nodeName == "TR") {
                    return
                }
                c.isImg = false;
                if (c.nodeName == "IMG") {
                    if (c.src.toLowerCase().search(/\.png$/) != -1) {
                        c.isImg = true;
                        c.style.visibility = "hidden"
                    } else {
                        return
                    }
                } else {
                    if (c.currentStyle.backgroundImage.toLowerCase().search(".png") == -1) {
                        return
                    }
                }
                g = DD_belatedPNG;
                c.vml = {
                    color: {},
                    image: {}
                };
                b = {
                    shape: {},
                    fill: {}
                };
                for (a in c.vml) {
                    if (c.vml.hasOwnProperty(a)) {
                        for (d in b) {
                            if (b.hasOwnProperty(d)) {
                                f = g.ns + ":" + d;
                                c.vml[a][d] = document.createElement(f)
                            }
                        }
                        c.vml[a].shape.stroked = false;
                        c.vml[a].shape.appendChild(c.vml[a].fill);
                        c.parentNode.insertBefore(c.vml[a].shape, c)
                    }
                }
                c.vml.image.shape.fillcolor = "none";
                c.vml.image.fill.type = "tile";
                c.vml.color.fill.on = false;
                g.attachHandlers(c);
                g.giveLayout(c);
                g.giveLayout(c.offsetParent);
                c.vmlInitiated = true;
                g.applyVML(c)
            }
        };
        try {
            document.execCommand("BackgroundImageCache", false, true)
        } catch (r) {}
        DD_belatedPNG.createVmlNameSpace();
        DD_belatedPNG.createVmlStyleSheet();
        DD_belatedPNG.fix('.booklist,.booklist li .cover,.booklist li .flag,.info div,.info h3,.tosearch,.tipbtm,.tipinfo,.tip h3,.topspan,.btmspan,.artlist,.notice .fl span,.bookcover span,.infobtn i,.showbtn,.showbtn i,.topline,.btmline,.orglist,.toplist h3,.toplist h3 i,.toplist h3 .more,.flagtop1,.flagtop2,.flagtop3,.listimg a span,.booklist li .closebtn,.menus h3 i,.menulist li i,#topbar strong,#topbar .closes,.back');
    };